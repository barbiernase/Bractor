namespace ReactiveState;

/// <summary>
/// Static helpers for combining multiple LazyValues.
/// </summary>
public static class LazyValue
{
    /// <summary>
    /// Combines two LazyValues. Ready only if both are Ready.
    /// </summary>
    public static LazyValue<(T1, T2)> Combine<T1, T2>(
        LazyValue<T1> first,
        LazyValue<T2> second)
    {
        if (first.IsFailed) return LazyValue<(T1, T2)>.Failed(first.Error);
        if (second.IsFailed) return LazyValue<(T1, T2)>.Failed(second.Error);
        if (first.IsPending || second.IsPending) return LazyValue<(T1, T2)>.Pending;

        return LazyValue<(T1, T2)>.Ready((first.Value, second.Value));
    }

    /// <summary>
    /// Combines three LazyValues.
    /// </summary>
    public static LazyValue<(T1, T2, T3)> Combine<T1, T2, T3>(
        LazyValue<T1> first,
        LazyValue<T2> second,
        LazyValue<T3> third)
    {
        if (first.IsFailed) return LazyValue<(T1, T2, T3)>.Failed(first.Error);
        if (second.IsFailed) return LazyValue<(T1, T2, T3)>.Failed(second.Error);
        if (third.IsFailed) return LazyValue<(T1, T2, T3)>.Failed(third.Error);
        if (first.IsPending || second.IsPending || third.IsPending)
            return LazyValue<(T1, T2, T3)>.Pending;

        return LazyValue<(T1, T2, T3)>.Ready((first.Value, second.Value, third.Value));
    }

    /// <summary>
    /// Combines a list of LazyValues. Ready only if all are Ready.
    /// </summary>
    public static LazyValue<IReadOnlyList<T>> All<T>(IEnumerable<LazyValue<T>> values)
    {
        var list = values.ToList();
        var results = new List<T>(list.Count);

        foreach (var value in list)
        {
            if (value.IsFailed) return LazyValue<IReadOnlyList<T>>.Failed(value.Error);
            if (value.IsPending) return LazyValue<IReadOnlyList<T>>.Pending;
            results.Add(value.Value);
        }

        return LazyValue<IReadOnlyList<T>>.Ready(results);
    }

    /// <summary>
    /// Returns the first Ready value, or Pending if none ready, or first Failed.
    /// </summary>
    public static LazyValue<T> FirstReady<T>(IEnumerable<LazyValue<T>> values)
    {
        Exception? firstError = null;

        foreach (var value in values)
        {
            if (value.IsReady) return value;
            if (value.IsFailed) firstError ??= value.Error;
        }

        return firstError != null
            ? LazyValue<T>.Failed(firstError)
            : LazyValue<T>.Pending;
    }
}