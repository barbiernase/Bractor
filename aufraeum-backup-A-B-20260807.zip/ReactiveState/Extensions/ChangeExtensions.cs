namespace ReactiveState;

/// <summary>
/// Extension methods for working with changes.
/// </summary>
public static class ChangeExtensions
{
    /// <summary>
    /// Filters changes that affect the given path.
    /// </summary>
    public static IEnumerable<Change> Affecting(
        this IEnumerable<Change> changes,
        string pathPrefix)
    {
        return changes.Where(c => c.Affects(pathPrefix));
    }

    /// <summary>
    /// Filters changes by kind.
    /// </summary>
    public static IEnumerable<Change> OfKind(
        this IEnumerable<Change> changes,
        ChangeKind kind)
    {
        return changes.Where(c => c.Kind == kind);
    }

    /// <summary>
    /// Filters changes by multiple kinds.
    /// </summary>
    public static IEnumerable<Change> OfKinds(
        this IEnumerable<Change> changes,
        params ChangeKind[] kinds)
    {
        var kindSet = kinds.ToHashSet();
        return changes.Where(c => kindSet.Contains(c.Kind));
    }

    /// <summary>
    /// Gets all unique paths that were affected.
    /// </summary>
    public static IEnumerable<string> GetAffectedPaths(this IEnumerable<Change> changes)
    {
        return changes.Select(c => c.Path).Distinct();
    }

    /// <summary>
    /// Checks if any change affects the given path.
    /// </summary>
    public static bool HasChangesFor(this IEnumerable<Change> changes, string path)
    {
        return changes.Any(c => c.Path == path);
    }

    /// <summary>
    /// Checks if any change affects the given path or its children.
    /// </summary>
    public static bool HasChangesAffecting(this IEnumerable<Change> changes, string pathPrefix)
    {
        return changes.Any(c => c.Affects(pathPrefix));
    }

    /// <summary>
    /// Gets the most recent change for a path (last one wins).
    /// </summary>
    public static Change? GetLatestFor(this IEnumerable<Change> changes, string path)
    {
        return changes.LastOrDefault(c => c.Path == path);
    }
}