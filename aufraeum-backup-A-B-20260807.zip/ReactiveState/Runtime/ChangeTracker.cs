namespace ReactiveState.Runtime;

/// <summary>
/// Tracks dirty flags, changes, and versioning.
/// Single responsibility: Know what changed.
/// </summary>
public sealed class ChangeTracker
{
    private readonly HashSet<string> _dirty = new(StringComparer.Ordinal);
    private readonly List<Change> _changes = new();
    private readonly object _lock = new();
    private long _version;

    // ═══════════════════════════════════════════════════════════
    //  Version
    // ═══════════════════════════════════════════════════════════

    public long Version => Interlocked.Read(ref _version);

    public long IncrementVersion() => Interlocked.Increment(ref _version);

    // ═══════════════════════════════════════════════════════════
    //  Dirty Tracking
    // ═══════════════════════════════════════════════════════════

    public bool IsDirty(string path)
    {
        lock (_lock)
        {
            return _dirty.Contains(path);
        }
    }

    public void MarkDirty(string path)
    {
        lock (_lock)
        {
            _dirty.Add(path);
        }
    }

    public void MarkDirty(IEnumerable<string> paths)
    {
        lock (_lock)
        {
            foreach (var path in paths)
            {
                _dirty.Add(path);
            }
        }
    }

    public void ClearDirty(string path)
    {
        lock (_lock)
        {
            _dirty.Remove(path);
        }
    }

    public IReadOnlySet<string> GetDirtyPaths()
    {
        lock (_lock)
        {
            return _dirty.ToHashSet();
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Change Log
    // ═══════════════════════════════════════════════════════════

    public void RecordChange(Change change)
    {
        lock (_lock)
        {
            _changes.Add(change);
        }
    }

    public void RecordChanges(IEnumerable<Change> changes)
    {
        lock (_lock)
        {
            _changes.AddRange(changes);
        }
    }

    public IReadOnlyList<Change> GetChanges()
    {
        lock (_lock)
        {
            return _changes.ToList();
        }
    }

    public IReadOnlyList<Change> ConsumeChanges()
    {
        lock (_lock)
        {
            var result = _changes.ToList();
            _changes.Clear();
            return result;
        }
    }

    public bool HasChanges
    {
        get
        {
            lock (_lock)
            {
                return _changes.Count > 0;
            }
        }
    }

    public void ClearChanges()
    {
        lock (_lock)
        {
            _changes.Clear();
        }
    }
}