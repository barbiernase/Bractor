namespace ReactiveState.Runtime;

using ReactiveState.Graph;

/// <summary>
/// The core runtime that manages state reactivity.
/// </summary>
public sealed class ReactiveCore : IDisposable
{
    private readonly DependencyGraph _graph;
    private readonly HashSet<string> _dirty;
    private readonly List<Change> _changes;
    private readonly Dictionary<string, Func<ComputeResult>> _syncComputers;
    private readonly Dictionary<string, Func<Task<ComputeResult>>> _asyncComputers;
    private readonly ComputeQueue _computeQueue;
    private readonly ComputeWorker _worker;
    private readonly object _lock = new();

    private long _version;
    private bool _isDisposed;

    // ═══════════════════════════════════════════════════════════
    //  Construction
    // ═══════════════════════════════════════════════════════════

    public ReactiveCore(DependencyGraph graph)
    {
        _graph = graph;
        _dirty = new HashSet<string>(StringComparer.Ordinal);
        _changes = new List<Change>();
        _syncComputers = new Dictionary<string, Func<ComputeResult>>(StringComparer.Ordinal);
        _asyncComputers = new Dictionary<string, Func<Task<ComputeResult>>>(StringComparer.Ordinal);
        _computeQueue = new ComputeQueue();
        _worker = new ComputeWorker(_computeQueue, ComputeAsync, OnComputedChanges);

        // Initially mark all computed properties as dirty
        foreach (var node in _graph.Nodes)
        {
            if (node.IsComputed)
            {
                _dirty.Add(node.Path);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Events
    // ═══════════════════════════════════════════════════════════

    public event Action<IReadOnlyList<Change>>? OnChanges;

    // ═══════════════════════════════════════════════════════════
    //  Public Properties
    // ═══════════════════════════════════════════════════════════

    public DependencyGraph Graph => _graph;

    public long Version => Interlocked.Read(ref _version);

    public IReadOnlyList<Change> Changes
    {
        get
        {
            lock (_lock)
            {
                return _changes.ToList();
            }
        }
    }

    public bool HasChanges
    {
        get
        {
            lock (_lock)
            {
                return _changes.Count > 0;
            }
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Registration
    // ═══════════════════════════════════════════════════════════

    public void Register(string path, Func<ComputeResult> computer)
    {
        lock (_lock)
        {
            _syncComputers[path] = computer;
            
            // If already dirty, enqueue for computation
            if (_dirty.Contains(path))
            {
                var level = _graph.GetLevel(path);
                _computeQueue.Enqueue(path, level);
            }
        }
    }

    public void RegisterAsync(string path, Func<Task<ComputeResult>> computer)
    {
        lock (_lock)
        {
            _asyncComputers[path] = computer;
            
            // If already dirty, enqueue for computation
            if (_dirty.Contains(path))
            {
                var level = _graph.GetLevel(path);
                _computeQueue.Enqueue(path, level);
            }
        }
    }

    public void Unregister(string path)
    {
        lock (_lock)
        {
            _syncComputers.Remove(path);
            _asyncComputers.Remove(path);
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Mutation Notification
    // ═══════════════════════════════════════════════════════════

    public void NotifyChanged(string path, object? oldValue, object? newValue)
    {
        lock (_lock)
        {
            Interlocked.Increment(ref _version);
            _changes.Add(Change.Set(path, oldValue, newValue));
            MarkAffectedDirty(path);
        }
    }

    public void NotifyAdded(string collectionPath, object? item, string? itemId = null)
    {
        lock (_lock)
        {
            Interlocked.Increment(ref _version);
            _changes.Add(Change.Add(collectionPath, item));
            MarkAffectedDirty(collectionPath);
        }
    }

    public void NotifyRemoved(string collectionPath, object? item, string? itemId = null)
    {
        lock (_lock)
        {
            Interlocked.Increment(ref _version);
            _changes.Add(Change.Remove(collectionPath, item));
            MarkAffectedDirty(collectionPath);
        }
    }

    public void NotifyCleared(string collectionPath, int previousCount)
    {
        lock (_lock)
        {
            Interlocked.Increment(ref _version);
            _changes.Add(Change.Clear(collectionPath, previousCount));
            MarkAffectedDirty(collectionPath);
        }
    }

    public void NotifyItemChanged(
        string collectionPath,
        string itemId,
        string propertyName,
        object? oldValue,
        object? newValue)
    {
        var path = $"{collectionPath}[id:{itemId}].{propertyName}";

        lock (_lock)
        {
            Interlocked.Increment(ref _version);
            _changes.Add(Change.Set(path, oldValue, newValue));
            MarkAffectedDirty(path);
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Dirty Management
    // ═══════════════════════════════════════════════════════════

    public bool IsDirty(string path)
    {
        lock (_lock)
        {
            return _dirty.Contains(path);
        }
    }

    public IReadOnlySet<string> DirtyPaths
    {
        get
        {
            lock (_lock)
            {
                return _dirty.ToHashSet();
            }
        }
    }

    public void MarkDirty(string path)
    {
        lock (_lock)
        {
            _dirty.Add(path);
            EnqueueIfComputed(path);
        }
    }

    public void ClearDirty(string path)
    {
        lock (_lock)
        {
            _dirty.Remove(path);
        }
    }

    private void MarkAffectedDirty(string changedPath)
    {
        var affected = _graph.GetAffected(changedPath);

        foreach (var path in affected)
        {
            _dirty.Add(path);
            EnqueueIfComputed(path);  // Always try to enqueue
        }

        if (!_computeQueue.IsEmpty)
        {
            _worker.Signal();
        }
    }

    private void EnqueueIfComputed(string path)
    {
        var node = _graph.GetNode(path);
        var hasComputer = _syncComputers.ContainsKey(path) || _asyncComputers.ContainsKey(path);

        // Enqueue if it's a computed node OR has a registered computer
        if (node?.IsComputed == true || hasComputer)
        {
            var level = _graph.GetLevel(path);
            _computeQueue.Enqueue(path, level);
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Computation
    // ═══════════════════════════════════════════════════════════

    private async Task<ComputeResult> ComputeAsync(string path)
    {
        Func<ComputeResult>? syncComputer;
        Func<Task<ComputeResult>>? asyncComputer;

        lock (_lock)
        {
            _syncComputers.TryGetValue(path, out syncComputer);
            _asyncComputers.TryGetValue(path, out asyncComputer);
        }

        ComputeResult result;

        if (asyncComputer != null)
        {
            result = await asyncComputer();
        }
        else if (syncComputer != null)
        {
            result = syncComputer();
        }
        else
        {
            var templatePath = PropertyPath.ToTemplate(path);

            lock (_lock)
            {
                _syncComputers.TryGetValue(templatePath, out syncComputer);
                _asyncComputers.TryGetValue(templatePath, out asyncComputer);
            }

            if (asyncComputer != null)
            {
                result = await asyncComputer();
            }
            else if (syncComputer != null)
            {
                result = syncComputer();
            }
            else
            {
                return ComputeResult.Unchanged();
            }
        }

        lock (_lock)
        {
            _dirty.Remove(path);
        }

        return result;
    }

    /// <summary>
    /// Forces immediate synchronous computation of all dirty properties.
    /// </summary>
    public void ComputeAllSync()
    {
        while (_computeQueue.TryDequeue(out var path, out _))
        {
            Func<ComputeResult>? syncComputer;

            lock (_lock)
            {
                _syncComputers.TryGetValue(path, out syncComputer);
            }

            if (syncComputer != null)
            {
                var result = syncComputer();

                lock (_lock)
                {
                    _dirty.Remove(path);
                    
                    if (result.HasChanged)
                    {
                        _changes.Add(Change.Computed(path, result.OldValue, result.NewValue));
                    }
                }
            }
        }
    }

    /// <summary>
    /// Triggers computation of all registered dirty properties.
    /// </summary>
    public void TriggerComputation()
    {
        lock (_lock)
        {
            foreach (var path in _dirty)
            {
                EnqueueIfComputed(path);
            }
        }

        if (!_computeQueue.IsEmpty)
        {
            _worker.Signal();
        }
    }
    
    
    // In ReactiveCore.cs hinzufügen:

    /// <summary>
    /// Notifies that multiple items were added to a collection.
    /// </summary>
    public void NotifyAddedRange<T>(string collectionPath, IList<T> items)
    {
        lock (_lock)
        {
            Interlocked.Increment(ref _version);
            _changes.Add(new Change
            {
                Path = collectionPath,
                Kind = ChangeKind.Add,
                OldValue = null,
                NewValue = items
            });
            MarkAffectedDirty(collectionPath);
        }
    }

    /// <summary>
    /// Notifies that multiple items were removed from a collection.
    /// </summary>
    public void NotifyRemovedRange<T>(string collectionPath, IList<T> items)
    {
        lock (_lock)
        {
            Interlocked.Increment(ref _version);
            _changes.Add(new Change
            {
                Path = collectionPath,
                Kind = ChangeKind.Remove,
                OldValue = items,
                NewValue = null
            });
            MarkAffectedDirty(collectionPath);
        }
    }

    /// <summary>
    /// Notifies that a collection was replaced entirely.
    /// </summary>
    public void NotifyReplaced<T>(string collectionPath, int oldCount, IList<T> newItems)
    {
        lock (_lock)
        {
            Interlocked.Increment(ref _version);
            _changes.Add(new Change
            {
                Path = collectionPath,
                Kind = ChangeKind.Replace,
                OldValue = oldCount,
                NewValue = newItems
            });
            MarkAffectedDirty(collectionPath);
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Change Management
    // ═══════════════════════════════════════════════════════════

    public IReadOnlyList<Change> ConsumeChanges()
    {
        lock (_lock)
        {
            var result = _changes.ToList();
            _changes.Clear();
            return result;
        }
    }

    public void ClearChanges()
    {
        lock (_lock)
        {
            _changes.Clear();
        }
    }

    private void OnComputedChanges(IReadOnlyList<Change> computedChanges)
    {
        lock (_lock)
        {
            _changes.AddRange(computedChanges);
        }

        OnChanges?.Invoke(computedChanges);
    }

    // ═══════════════════════════════════════════════════════════
    //  Disposal
    // ═══════════════════════════════════════════════════════════

    public void Dispose()
    {
        if (_isDisposed)
            return;

        _isDisposed = true;
        _worker.Dispose();
    }
}