namespace ReactiveState;

using ReactiveState.Graph;
using ReactiveState.Runtime;

/// <summary>
/// Non-generic interface for state notification.
/// Used by generated state classes and TrackedList.
/// </summary>
public interface IStateStore
{
    long Version { get; }
    bool HasChanges { get; }
    
    void NotifyChanged(string path, object? oldValue, object? newValue);
    void NotifyAdded(string collectionPath, object? item, string? itemId = null);
    void NotifyRemoved(string collectionPath, object? item, string? itemId = null);
    void NotifyCleared(string collectionPath, int previousCount);
    void NotifyItemChanged(string collectionPath, string itemId, string propertyName, object? oldValue, object? newValue);
    
    void RegisterComputed(string path, Func<object?> compute);
    void RegisterComputedAsync(string path, Func<Task<object?>> compute);
    void UnregisterComputed(string path);
    
    LazyValue<T> GetComputed<T>(string path);
    bool IsDirty(string path);
    
    IDisposable Subscribe(string path, Action<Change> handler);
}

/// <summary>
/// Interface for state classes that can connect to a StateStore.
/// Implemented by generated code.
/// </summary>
public interface IConnectableState
{
    void __Connect(IStateStore store);
    void __Disconnect();
}

/// <summary>
/// The main entry point for reactive state management.
/// Facade that coordinates all internal components.
/// </summary>
public sealed class StateStore<TState> : IStateStore, IDisposable where TState : class
{
    private readonly TState _state;
    private readonly DependencyGraph _graph;
    private readonly ChangeTracker _changeTracker;
    private readonly SubscriptionHub _subscriptions;
    private readonly ComputeEngine _engine;
    private readonly ComputeScheduler _scheduler;
    private bool _isDisposed;

    // ═══════════════════════════════════════════════════════════
    //  Construction
    // ═══════════════════════════════════════════════════════════

    public StateStore(TState state, DependencyGraph graph, StateStoreOptions? options = null)
    {
        ArgumentNullException.ThrowIfNull(state);
        ArgumentNullException.ThrowIfNull(graph);

        options ??= new StateStoreOptions();

        _state = state;
        _graph = graph;

        // Create internal components
        _changeTracker = new ChangeTracker();
        _subscriptions = new SubscriptionHub();
        _engine = new ComputeEngine();
        _scheduler = new ComputeScheduler(
            _graph,
            _changeTracker,
            _subscriptions,
            _engine,
            options.DebounceTime
        );

        // Configure scheduler
        _scheduler.UseDebouncing = options.UseDebouncing;
        _scheduler.OnlyComputeSubscribed = options.OnlyComputeSubscribed;

        // Initialize dirty flags for all computed properties
        foreach (var node in _graph.Nodes)
        {
            if (node.IsComputed)
            {
                _changeTracker.MarkDirty(node.Path);
            }
        }

        // Connect state to this store (if state supports it)
        if (_state is IConnectableState connectable)
        {
            connectable.__Connect(this);
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Public Properties
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// The state object. Use for reading values.
    /// For mutations, use the state's own methods.
    /// </summary>
    public TState State => _state;

    /// <summary>
    /// Current version. Increments with every mutation.
    /// </summary>
    public long Version => _changeTracker.Version;

    /// <summary>
    /// Whether there are pending changes that haven't been consumed.
    /// </summary>
    public bool HasChanges => _changeTracker.HasChanges;

    /// <summary>
    /// The dependency graph.
    /// </summary>
    public DependencyGraph Graph => _graph;

    // ═══════════════════════════════════════════════════════════
    //  Subscriptions
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Subscribes to changes at the given path.
    /// Supports template paths like "Todos[*].Title".
    /// </summary>
    public IDisposable Subscribe(string path, Action<Change> handler)
    {
        return _subscriptions.Subscribe(path, handler);
    }

    /// <summary>
    /// Subscribes to changes at multiple paths.
    /// </summary>
    public IDisposable Subscribe(IEnumerable<string> paths, Action<Change> handler)
    {
        return _subscriptions.Subscribe(paths, handler);
    }

    /// <summary>
    /// Subscribes to all changes.
    /// </summary>
    public IDisposable SubscribeAll(Action<Change> handler)
    {
        // Subscribe to root - gets notified of everything
        return _subscriptions.Subscribe("*", handler);
    }

    /// <summary>
    /// Returns true if the path has active subscribers.
    /// </summary>
    public bool HasSubscribers(string path)
    {
        return _subscriptions.HasSubscribersFor(path);
    }

    // ═══════════════════════════════════════════════════════════
    //  Computed Property Registration
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Registers a synchronous computed property.
    /// </summary>
    public void RegisterComputed(string path, Func<object?> compute)
    {
        var level = _graph.GetLevel(path);
        _engine.Register(path, level, compute);
    }

    /// <summary>
    /// Registers an asynchronous computed property.
    /// </summary>
    public void RegisterComputedAsync(string path, Func<Task<object?>> compute)
    {
        var level = _graph.GetLevel(path);
        _engine.RegisterAsync(path, level, compute);
    }

    /// <summary>
    /// Unregisters a computed property.
    /// </summary>
    public void UnregisterComputed(string path)
    {
        _engine.Unregister(path);
    }

    // ═══════════════════════════════════════════════════════════
    //  Value Access
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Gets a computed value as LazyValue.
    /// Returns Pending if not yet computed.
    /// </summary>
    public LazyValue<T> GetComputed<T>(string path)
    {
        return _engine.GetCached<T>(path);
    }

    /// <summary>
    /// Returns true if the path is dirty (needs recomputation).
    /// </summary>
    public bool IsDirty(string path)
    {
        return _changeTracker.IsDirty(path);
    }

    // ═══════════════════════════════════════════════════════════
    //  Mutation Notifications (called by generated state code)
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Notifies that a tracked property changed.
    /// Called by generated property setters.
    /// </summary>
    public void NotifyChanged(string path, object? oldValue, object? newValue)
    {
        _scheduler.OnMutation(path, oldValue, newValue);
    }

    /// <summary>
    /// Notifies that an item was added to a collection.
    /// </summary>
    public void NotifyAdded(string collectionPath, object? item, string? itemId = null)
    {
        _scheduler.OnAdded(collectionPath, item, itemId);
    }

    /// <summary>
    /// Notifies that an item was removed from a collection.
    /// </summary>
    public void NotifyRemoved(string collectionPath, object? item, string? itemId = null)
    {
        _scheduler.OnRemoved(collectionPath, item, itemId);
    }

    /// <summary>
    /// Notifies that a collection was cleared.
    /// </summary>
    public void NotifyCleared(string collectionPath, int previousCount)
    {
        _scheduler.OnCleared(collectionPath, previousCount);
    }

    /// <summary>
    /// Notifies that a collection item property changed.
    /// </summary>
    public void NotifyItemChanged(string collectionPath, string itemId, string propertyName, object? oldValue, object? newValue)
    {
        _scheduler.OnItemChanged(collectionPath, itemId, propertyName, oldValue, newValue);
    }

    // ═══════════════════════════════════════════════════════════
    //  Change Management
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Gets all pending changes without clearing them.
    /// </summary>
    public IReadOnlyList<Change> GetChanges()
    {
        return _changeTracker.GetChanges();
    }

    /// <summary>
    /// Consumes and clears all pending changes.
    /// </summary>
    public IReadOnlyList<Change> ConsumeChanges()
    {
        return _changeTracker.ConsumeChanges();
    }

    // ═══════════════════════════════════════════════════════════
    //  Manual Control
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Forces immediate computation of all pending computations.
    /// Bypasses debouncing.
    /// </summary>
    public void Flush()
    {
        _scheduler.Flush();
    }

    /// <summary>
    /// Forces immediate synchronous computation.
    /// Useful for testing.
    /// </summary>
    public IReadOnlyList<Change> FlushSync()
    {
        return _scheduler.FlushSync();
    }

    // ═══════════════════════════════════════════════════════════
    //  Disposal
    // ═══════════════════════════════════════════════════════════

    public void Dispose()
    {
        if (_isDisposed)
            return;

        _isDisposed = true;

        // Disconnect state
        if (_state is IConnectableState connectable)
        {
            connectable.__Disconnect();
        }

        _scheduler.Dispose();
        _engine.Dispose();
    }
}

// ═══════════════════════════════════════════════════════════
//  Options
// ═══════════════════════════════════════════════════════════

/// <summary>
/// Configuration options for StateStore.
/// </summary>
public sealed class StateStoreOptions
{
    /// <summary>
    /// Debounce time for batching mutations. Default: 16ms.
    /// </summary>
    public TimeSpan DebounceTime { get; set; } = TimeSpan.FromMilliseconds(16);

    /// <summary>
    /// Whether to use debouncing. Default: true.
    /// </summary>
    public bool UseDebouncing { get; set; } = true;

    /// <summary>
    /// Whether to only compute paths with subscribers. Default: true.
    /// </summary>
    public bool OnlyComputeSubscribed { get; set; } = true;
}