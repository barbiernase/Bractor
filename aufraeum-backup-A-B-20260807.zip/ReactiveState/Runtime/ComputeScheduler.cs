namespace ReactiveState.Runtime;

using ReactiveState.Graph;

/// <summary>
/// Coordinates when computations happen.
/// Single responsibility: Decide when to compute.
/// </summary>
public sealed class ComputeScheduler : IDisposable
{
    private readonly DependencyGraph _graph;
    private readonly ChangeTracker _changeTracker;
    private readonly SubscriptionHub _subscriptions;
    private readonly ComputeEngine _engine;
    
    private readonly HashSet<string> _pendingPaths = new(StringComparer.Ordinal);
    private readonly object _lock = new();
    
    private readonly Timer _debounceTimer;
    private readonly TimeSpan _debounceTime;
    private bool _isDisposed;

    // ═══════════════════════════════════════════════════════════
    //  Construction
    // ═══════════════════════════════════════════════════════════

    public ComputeScheduler(
        DependencyGraph graph,
        ChangeTracker changeTracker,
        SubscriptionHub subscriptions,
        ComputeEngine engine,
        TimeSpan? debounceTime = null)
    {
        _graph = graph;
        _changeTracker = changeTracker;
        _subscriptions = subscriptions;
        _engine = engine;
        _debounceTime = debounceTime ?? TimeSpan.FromMilliseconds(16);

        _debounceTimer = new Timer(OnDebounceElapsed, null, Timeout.Infinite, Timeout.Infinite);

        // React to first subscriber
        _subscriptions.OnFirstSubscriber += OnFirstSubscriber;

        // React to computed changes (cascade)
        _engine.OnComputed += OnComputedChanges;
    }

    // ═══════════════════════════════════════════════════════════
    //  Configuration
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Whether to use debouncing. Default: true.
    /// </summary>
    public bool UseDebouncing { get; set; } = true;

    /// <summary>
    /// Whether to only compute paths with subscribers. Default: true.
    /// </summary>
    public bool OnlyComputeSubscribed { get; set; } = true;

    // ═══════════════════════════════════════════════════════════
    //  Mutation Handling
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Called when a tracked property changes.
    /// Schedules affected computed properties.
    /// </summary>
    public void OnMutation(string path, object? oldValue, object? newValue)
    {
        // Record the change
        _changeTracker.IncrementVersion();
        _changeTracker.RecordChange(Change.Set(path, oldValue, newValue));

        // Find affected paths
        var affected = _graph.GetAffected(path);

        // Mark dirty and schedule
        ScheduleAffected(affected);
    }

    /// <summary>
    /// Called when a collection item is added.
    /// </summary>
    public void OnAdded(string collectionPath, object? item, string? itemId = null)
    {
        _changeTracker.IncrementVersion();
        _changeTracker.RecordChange(Change.Add(collectionPath, item));

        var affected = _graph.GetAffectedByCollectionChange(collectionPath);
        ScheduleAffected(affected);
    }

    /// <summary>
    /// Called when a collection item is removed.
    /// </summary>
    public void OnRemoved(string collectionPath, object? item, string? itemId = null)
    {
        _changeTracker.IncrementVersion();
        _changeTracker.RecordChange(Change.Remove(collectionPath, item));

        var affected = _graph.GetAffectedByCollectionChange(collectionPath);
        ScheduleAffected(affected);
    }

    /// <summary>
    /// Called when a collection is cleared.
    /// </summary>
    public void OnCleared(string collectionPath, int previousCount)
    {
        _changeTracker.IncrementVersion();
        _changeTracker.RecordChange(Change.Clear(collectionPath, previousCount));

        var affected = _graph.GetAffectedByCollectionChange(collectionPath);
        ScheduleAffected(affected);
    }

    /// <summary>
    /// Called when a collection item property changes.
    /// </summary>
    public void OnItemChanged(string collectionPath, string itemId, string propertyName, object? oldValue, object? newValue)
    {
        var path = $"{collectionPath}[id:{itemId}].{propertyName}";

        _changeTracker.IncrementVersion();
        _changeTracker.RecordChange(Change.Set(path, oldValue, newValue));

        var affected = _graph.GetAffectedByItemChange(collectionPath, itemId, propertyName);
        ScheduleAffected(affected);
    }

    // ═══════════════════════════════════════════════════════════
    //  Scheduling Logic
    // ═══════════════════════════════════════════════════════════

    private void ScheduleAffected(IReadOnlyList<string> affectedPaths)
    {
        lock (_lock)
        {
            foreach (var path in affectedPaths)
            {
                // Mark as dirty
                _changeTracker.MarkDirty(path);

                // Only schedule if someone cares (or if configured to compute all)
                if (!OnlyComputeSubscribed || _subscriptions.HasSubscribersFor(path))
                {
                    _pendingPaths.Add(path);
                }
            }

            if (_pendingPaths.Count > 0)
            {
                if (UseDebouncing)
                {
                    // Reset debounce timer
                    _debounceTimer.Change(_debounceTime, Timeout.InfiniteTimeSpan);
                }
                else
                {
                    // Immediate - but use background worker
                    FlushToEngine();
                }
            }
        }
    }

    private void OnDebounceElapsed(object? state)
    {
        lock (_lock)
        {
            FlushToEngine();
        }
    }

    private void FlushToEngine()
    {
        if (_pendingPaths.Count == 0)
            return;

        var pathsToCompute = _pendingPaths.ToList();
        _pendingPaths.Clear();

        // Schedule in engine (it handles level-based ordering via background worker)
        _engine.Schedule(pathsToCompute);
    }

    // ═══════════════════════════════════════════════════════════
    //  Manual Control
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Forces immediate computation of all pending paths.
    /// Bypasses debouncing but still uses background worker.
    /// </summary>
    public void Flush()
    {
        lock (_lock)
        {
            _debounceTimer.Change(Timeout.Infinite, Timeout.Infinite);
            FlushToEngine();
        }
    }

    /// <summary>
    /// Forces immediate SYNCHRONOUS computation of all pending paths.
    /// Bypasses debouncing AND background worker.
    /// Useful for testing.
    /// </summary>
    public IReadOnlyList<Change> FlushSync()
    {
        // Stop debounce timer
        _debounceTimer.Change(Timeout.Infinite, Timeout.Infinite);

        List<string> pathsToCompute;
        lock (_lock)
        {
            if (_pendingPaths.Count == 0)
                return Array.Empty<Change>();

            pathsToCompute = _pendingPaths.ToList();
            _pendingPaths.Clear();
        }

        // Sort by level for correct computation order
        var sortedPaths = pathsToCompute
            .OrderBy(p => _graph.GetLevel(p))
            .ToList();

        var allChanges = new List<Change>();

        // Compute synchronously - bypass the background worker entirely
        foreach (var path in sortedPaths)
        {
            // Skip if no computer registered
            if (!_engine.IsRegistered(path))
                continue;

            var result = _engine.ComputeSync(path);
            
            if (result.HasChanged)
            {
                var change = Change.Computed(path, result.OldValue, result.NewValue);
                allChanges.Add(change);
                
                _changeTracker.ClearDirty(path);
                _changeTracker.RecordChange(change);
                
                // Notify subscribers synchronously
                _subscriptions.Notify(change);
            }
        }

        return allChanges;
    }

    /// <summary>
    /// Schedules a specific path for computation.
    /// </summary>
    public void Schedule(string path)
    {
        lock (_lock)
        {
            _pendingPaths.Add(path);

            if (UseDebouncing)
            {
                _debounceTimer.Change(_debounceTime, Timeout.InfiniteTimeSpan);
            }
            else
            {
                FlushToEngine();
            }
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Event Handlers
    // ═══════════════════════════════════════════════════════════

    private void OnFirstSubscriber(string path)
    {
        // Someone subscribed to a path - if it's dirty, compute it
        if (_changeTracker.IsDirty(path))
        {
            Schedule(path);
        }
    }

    private void OnComputedChanges(IReadOnlyList<Change> changes)
    {
        // Record computed changes
        _changeTracker.RecordChanges(changes);

        // Clear dirty flags for computed paths
        foreach (var change in changes)
        {
            _changeTracker.ClearDirty(change.Path);
        }

        // Notify subscribers
        _subscriptions.Notify(changes);

        // Check for cascading dependencies
        foreach (var change in changes)
        {
            var furtherAffected = _graph.GetAffected(change.Path);
            if (furtherAffected.Count > 0)
            {
                // Only schedule paths that are still dirty
                var toSchedule = furtherAffected
                    .Where(p => _changeTracker.IsDirty(p))
                    .ToList();
                
                if (toSchedule.Count > 0)
                {
                    ScheduleAffected(toSchedule);
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Disposal
    // ═══════════════════════════════════════════════════════════

    public void Dispose()
    {
        if (_isDisposed)
            return;

        _isDisposed = true;

        _subscriptions.OnFirstSubscriber -= OnFirstSubscriber;
        _engine.OnComputed -= OnComputedChanges;

        _debounceTimer.Dispose();
    }
}