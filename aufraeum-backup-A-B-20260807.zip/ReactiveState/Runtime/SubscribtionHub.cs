namespace ReactiveState.Runtime;

using ReactiveState.Graph;

/// <summary>
/// Manages subscriptions and notifies subscribers of changes.
/// Single responsibility: Know who cares about what.
/// </summary>
public sealed class SubscriptionHub
{
    private readonly Dictionary<string, List<SubscriptionEntry>> _subscriptions = new(StringComparer.Ordinal);
    private readonly object _lock = new();
    private long _nextId;

    /// <summary>
    /// Fired when the first subscriber for a path subscribes.
    /// Useful to trigger initial computation.
    /// </summary>
    public event Action<string>? OnFirstSubscriber;

    /// <summary>
    /// Fired when the last subscriber for a path unsubscribes.
    /// </summary>
    public event Action<string>? OnLastUnsubscribe;

    // ═══════════════════════════════════════════════════════════
    //  Subscribe
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Subscribes to changes at the given path.
    /// Supports template paths like "Todos[*].Title".
    /// </summary>
    public IDisposable Subscribe(string path, Action<Change> handler)
    {
        ArgumentNullException.ThrowIfNull(handler);

        var id = Interlocked.Increment(ref _nextId);
        var entry = new SubscriptionEntry(id, path, handler);
        bool isFirst;

        lock (_lock)
        {
            if (!_subscriptions.TryGetValue(path, out var list))
            {
                list = new List<SubscriptionEntry>();
                _subscriptions[path] = list;
            }

            isFirst = list.Count == 0;
            list.Add(entry);
        }

        if (isFirst)
        {
            OnFirstSubscriber?.Invoke(path);
        }

        return new Subscription(() => Unsubscribe(path, id));
    }

    /// <summary>
    /// Subscribes to multiple paths at once.
    /// </summary>
    public IDisposable Subscribe(IEnumerable<string> paths, Action<Change> handler)
    {
        var disposables = paths.Select(p => Subscribe(p, handler)).ToList();
        return new CompositeDisposable(disposables);
    }

    private void Unsubscribe(string path, long id)
    {
        bool wasLast = false;

        lock (_lock)
        {
            if (_subscriptions.TryGetValue(path, out var list))
            {
                list.RemoveAll(e => e.Id == id);
                wasLast = list.Count == 0;

                if (wasLast)
                {
                    _subscriptions.Remove(path);
                }
            }
        }

        if (wasLast)
        {
            OnLastUnsubscribe?.Invoke(path);
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Query
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Returns true if anyone is subscribed to this exact path.
    /// </summary>
    public bool HasSubscribers(string path)
    {
        lock (_lock)
        {
            return _subscriptions.TryGetValue(path, out var list) && list.Count > 0;
        }
    }

    /// <summary>
    /// Returns true if anyone is subscribed to this path or a matching template.
    /// </summary>
    public bool HasSubscribersFor(string instancePath)
    {
        lock (_lock)
        {
            // Direct match
            if (_subscriptions.TryGetValue(instancePath, out var list) && list.Count > 0)
                return true;

            // Template match: check if any template subscription matches
            var templatePath = PropertyPath.ToTemplate(instancePath);
            if (templatePath != instancePath)
            {
                if (_subscriptions.TryGetValue(templatePath, out list) && list.Count > 0)
                    return true;
            }

            // Check if any subscribed path would match this instance
            foreach (var subscribedPath in _subscriptions.Keys)
            {
                if (PathMatches(instancePath, subscribedPath))
                    return true;
            }

            return false;
        }
    }

    /// <summary>
    /// Gets all paths that have active subscriptions.
    /// </summary>
    public IReadOnlyList<string> GetSubscribedPaths()
    {
        lock (_lock)
        {
            return _subscriptions.Keys.ToList();
        }
    }

    /// <summary>
    /// Gets the subscriber count for a path.
    /// </summary>
    public int GetSubscriberCount(string path)
    {
        lock (_lock)
        {
            return _subscriptions.TryGetValue(path, out var list) ? list.Count : 0;
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Notify
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Notifies all matching subscribers of a change.
    /// Handles template matching automatically.
    /// </summary>
    public void Notify(Change change)
    {
        var handlers = GetMatchingHandlers(change.Path);

        foreach (var handler in handlers)
        {
            try
            {
                handler(change);
            }
            catch
            {
                // Subscriber threw - don't break other subscribers
            }
        }
    }

    /// <summary>
    /// Notifies subscribers of multiple changes.
    /// </summary>
    public void Notify(IEnumerable<Change> changes)
    {
        foreach (var change in changes)
        {
            Notify(change);
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Matching Logic
    // ═══════════════════════════════════════════════════════════

    private List<Action<Change>> GetMatchingHandlers(string changePath)
    {
        var result = new List<Action<Change>>();

        lock (_lock)
        {
            foreach (var (subscribedPath, entries) in _subscriptions)
            {
                if (entries.Count == 0)
                    continue;

                if (PathMatches(changePath, subscribedPath))
                {
                    result.AddRange(entries.Select(e => e.Handler));
                }
            }
        }

        return result;
    }

    /// <summary>
    /// Checks if a change path matches a subscribed path.
    /// </summary>
    private static bool PathMatches(string changePath, string subscribedPath)
    {
        // Exact match
        if (changePath == subscribedPath)
            return true;

        // Wildcard "*" matches everything
        if (subscribedPath == "*")
            return true;

        // Template match: "Todos[*].Title" matches "Todos[id:abc].Title"
        if (PropertyPath.IsTemplate(subscribedPath))
        {
            return PropertyPath.Matches(changePath, subscribedPath);
        }

        // Parent match: subscribing to "Todos" gets notified for "Todos[id:x].Title"
        if (PropertyPath.IsChildOf(changePath, subscribedPath))
            return true;

        // Reverse template match: subscribing to "Todos[id:abc].Title" 
        // should NOT match template "Todos[*].Title" in change
        // (this case shouldn't happen in practice, but be safe)

        return false;
    }

    // ═══════════════════════════════════════════════════════════
    //  Inner Types
    // ═══════════════════════════════════════════════════════════

    private sealed record SubscriptionEntry(long Id, string Path, Action<Change> Handler);

    private sealed class Subscription : IDisposable
    {
        private Action? _onDispose;

        public Subscription(Action onDispose) => _onDispose = onDispose;

        public void Dispose()
        {
            Interlocked.Exchange(ref _onDispose, null)?.Invoke();
        }
    }

    private sealed class CompositeDisposable : IDisposable
    {
        private List<IDisposable>? _disposables;

        public CompositeDisposable(List<IDisposable> disposables) => _disposables = disposables;

        public void Dispose()
        {
            var list = Interlocked.Exchange(ref _disposables, null);
            if (list != null)
            {
                foreach (var d in list)
                {
                    d.Dispose();
                }
            }
        }
    }
}