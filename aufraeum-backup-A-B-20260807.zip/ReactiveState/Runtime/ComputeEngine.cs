namespace ReactiveState.Runtime;

using System.Threading.Channels;

/// <summary>
/// Executes computations and caches results.
/// Single responsibility: Compute values and cache them.
/// </summary>
public sealed class ComputeEngine : IDisposable
{
    private readonly Dictionary<string, RegisteredComputer> _computers = new(StringComparer.Ordinal);
    private readonly Dictionary<string, CachedValue> _cache = new(StringComparer.Ordinal);
    private readonly ComputeQueue _queue;
    private readonly Channel<bool> _signal;
    private readonly CancellationTokenSource _cts;
    private readonly Task _workerTask;
    private readonly object _lock = new();
    private bool _isDisposed;

    /// <summary>
    /// Fired when computations complete with changes.
    /// </summary>
    public event Action<IReadOnlyList<Change>>? OnComputed;

    // ═══════════════════════════════════════════════════════════
    //  Construction
    // ═══════════════════════════════════════════════════════════

    public ComputeEngine()
    {
        _queue = new ComputeQueue();
        _cts = new CancellationTokenSource();
        _signal = Channel.CreateBounded<bool>(new BoundedChannelOptions(1)
        {
            FullMode = BoundedChannelFullMode.DropOldest
        });
        _workerTask = Task.Run(WorkerLoop);
    }

    // ═══════════════════════════════════════════════════════════
    //  Registration
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Registers a synchronous compute function.
    /// </summary>
    public void Register(string path, int level, Func<object?> compute)
    {
        ArgumentNullException.ThrowIfNull(compute);

        lock (_lock)
        {
            _computers[path] = new RegisteredComputer(path, level, compute, null);
        }
    }

    /// <summary>
    /// Registers an asynchronous compute function.
    /// </summary>
    public void RegisterAsync(string path, int level, Func<Task<object?>> computeAsync)
    {
        ArgumentNullException.ThrowIfNull(computeAsync);

        lock (_lock)
        {
            _computers[path] = new RegisteredComputer(path, level, null, computeAsync);
        }
    }

    /// <summary>
    /// Unregisters a compute function and clears its cache.
    /// </summary>
    public void Unregister(string path)
    {
        lock (_lock)
        {
            _computers.Remove(path);
            _cache.Remove(path);
        }
    }

    /// <summary>
    /// Returns true if a computer is registered for this path.
    /// </summary>
    public bool IsRegistered(string path)
    {
        lock (_lock)
        {
            return _computers.ContainsKey(path);
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Cache Access
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Gets the cached value as LazyValue.
    /// Returns Pending if not yet computed.
    /// </summary>
    public LazyValue<T> GetCached<T>(string path)
    {
        lock (_lock)
        {
            if (_cache.TryGetValue(path, out var cached))
            {
                if (cached.Error != null)
                    return LazyValue<T>.Failed(cached.Error);
                
                if (cached.Value is T typed)
                    return LazyValue<T>.Ready(typed);
                
                if (cached.Value == null)
                    return LazyValue<T>.Ready(default!);
            }
            
            return LazyValue<T>.Pending;
        }
    }

    /// <summary>
    /// Gets the cached value or null if not computed.
    /// </summary>
    public object? GetCachedRaw(string path)
    {
        lock (_lock)
        {
            return _cache.TryGetValue(path, out var cached) ? cached.Value : null;
        }
    }

    /// <summary>
    /// Returns true if a value is cached for this path.
    /// </summary>
    public bool HasCached(string path)
    {
        lock (_lock)
        {
            return _cache.ContainsKey(path);
        }
    }

    /// <summary>
    /// Invalidates the cache for a path.
    /// </summary>
    public void InvalidateCache(string path)
    {
        lock (_lock)
        {
            _cache.Remove(path);
        }
    }

    /// <summary>
    /// Invalidates all cached values.
    /// </summary>
    public void InvalidateAll()
    {
        lock (_lock)
        {
            _cache.Clear();
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Scheduling
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Schedules a path for computation.
    /// </summary>
    public bool Schedule(string path)
    {
        lock (_lock)
        {
            if (!_computers.TryGetValue(path, out var computer))
                return false;

            if (_queue.Enqueue(path, computer.Level))
            {
                Signal();
                return true;
            }
            return false;
        }
    }

    /// <summary>
    /// Schedules multiple paths for computation.
    /// </summary>
    public int Schedule(IEnumerable<string> paths)
    {
        int count = 0;
        lock (_lock)
        {
            foreach (var path in paths)
            {
                if (_computers.TryGetValue(path, out var computer))
                {
                    if (_queue.Enqueue(path, computer.Level))
                        count++;
                }
            }
        }

        if (count > 0)
            Signal();

        return count;
    }

    private void Signal()
    {
        if (!_isDisposed)
        {
            _signal.Writer.TryWrite(true);
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Synchronous Computation
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Computes a value synchronously. Returns immediately if cached.
    /// </summary>
    public ComputeResult ComputeSync(string path)
    {
        RegisteredComputer? computer;
        CachedValue? existingCache;

        lock (_lock)
        {
            _computers.TryGetValue(path, out computer);
            _cache.TryGetValue(path, out existingCache);
        }

        if (computer == null)
            return ComputeResult.Unchanged();

        if (computer.SyncCompute == null)
            throw new InvalidOperationException($"Path '{path}' has no synchronous compute function.");

        try
        {
            var newValue = computer.SyncCompute();
            var oldValue = existingCache?.Value;
            var hasChanged = !Equals(oldValue, newValue);

            lock (_lock)
            {
                _cache[path] = new CachedValue(newValue, null);
            }

            return hasChanged
                ? ComputeResult.Changed(oldValue, newValue)
                : ComputeResult.Unchanged();
        }
        catch (Exception ex)
        {
            lock (_lock)
            {
                _cache[path] = new CachedValue(null, ex);
            }

            return ComputeResult.Changed(existingCache?.Value, ex);
        }
    }

    /// <summary>
    /// Computes all scheduled sync computations immediately.
    /// Returns list of changes.
    /// </summary>
    public IReadOnlyList<Change> FlushSync()
    {
        var changes = new List<Change>();

        while (_queue.TryDequeue(out var path, out _))
        {
            RegisteredComputer? computer;
            lock (_lock)
            {
                _computers.TryGetValue(path, out computer);
            }

            if (computer?.SyncCompute != null)
            {
                var result = ComputeSync(path);
                if (result.HasChanged)
                {
                    changes.Add(Change.Computed(path, result.OldValue, result.NewValue));
                }
            }
        }

        return changes;
    }

    // ═══════════════════════════════════════════════════════════
    //  Background Worker
    // ═══════════════════════════════════════════════════════════

    private async Task WorkerLoop()
    {
        var changes = new List<Change>();

        try
        {
            while (!_cts.Token.IsCancellationRequested)
            {
                await _signal.Reader.WaitToReadAsync(_cts.Token);

                // Drain signal channel
                while (_signal.Reader.TryRead(out _)) { }

                // Process queue
                while (_queue.TryDequeue(out var path, out _))
                {
                    if (_cts.Token.IsCancellationRequested)
                        break;

                    var result = await ComputeAsyncInternal(path);

                    if (result.HasChanged)
                    {
                        changes.Add(Change.Computed(path, result.OldValue, result.NewValue));
                    }
                }

                // Emit changes
                if (changes.Count > 0)
                {
                    OnComputed?.Invoke(changes.ToList());
                    changes.Clear();
                }
            }
        }
        catch (OperationCanceledException)
        {
            // Expected on dispose
        }
    }

    private async Task<ComputeResult> ComputeAsyncInternal(string path)
    {
        RegisteredComputer? computer;
        CachedValue? existingCache;

        lock (_lock)
        {
            _computers.TryGetValue(path, out computer);
            _cache.TryGetValue(path, out existingCache);
        }

        if (computer == null)
            return ComputeResult.Unchanged();

        try
        {
            object? newValue;

            if (computer.AsyncCompute != null)
            {
                newValue = await computer.AsyncCompute();
            }
            else if (computer.SyncCompute != null)
            {
                newValue = computer.SyncCompute();
            }
            else
            {
                return ComputeResult.Unchanged();
            }

            var oldValue = existingCache?.Value;
            var hasChanged = !Equals(oldValue, newValue);

            lock (_lock)
            {
                _cache[path] = new CachedValue(newValue, null);
            }

            return hasChanged
                ? ComputeResult.Changed(oldValue, newValue)
                : ComputeResult.Unchanged();
        }
        catch (Exception ex)
        {
            lock (_lock)
            {
                _cache[path] = new CachedValue(null, ex);
            }

            return ComputeResult.Changed(existingCache?.Value, ex);
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Disposal
    // ═══════════════════════════════════════════════════════════

    public void Dispose()
    {
        if (_isDisposed)
            return;

        _isDisposed = true;
        _signal.Writer.Complete();

        try
        {
            _cts.Cancel();
        }
        catch (ObjectDisposedException)
        {
            // Already disposed
        }

        try
        {
            _workerTask.Wait(TimeSpan.FromSeconds(1));
        }
        catch (AggregateException)
        {
            // Task cancelled
        }

        _cts.Dispose();
    }

    // ═══════════════════════════════════════════════════════════
    //  Inner Types
    // ═══════════════════════════════════════════════════════════

    private sealed record RegisteredComputer(
        string Path,
        int Level,
        Func<object?>? SyncCompute,
        Func<Task<object?>>? AsyncCompute
    );

    private sealed record CachedValue(object? Value, Exception? Error);
}