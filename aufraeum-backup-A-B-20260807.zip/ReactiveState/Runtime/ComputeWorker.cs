namespace ReactiveState.Runtime;

using System.Threading.Channels;

/// <summary>
/// Background worker that processes the compute queue.
/// </summary>
public sealed class ComputeWorker : IDisposable
{
    private readonly ComputeQueue _queue;
    private readonly Func<string, Task<ComputeResult>> _computeAsync;
    private readonly Action<IReadOnlyList<Change>> _onChanges;
    private readonly CancellationTokenSource _cts;
    private readonly Task _workerTask;
    private readonly Channel<bool> _signal;
    private bool _isDisposed;

    public ComputeWorker(
        ComputeQueue queue,
        Func<string, Task<ComputeResult>> computeAsync,
        Action<IReadOnlyList<Change>> onChanges)
    {
        _queue = queue;
        _computeAsync = computeAsync;
        _onChanges = onChanges;
        _cts = new CancellationTokenSource();
        _signal = Channel.CreateBounded<bool>(new BoundedChannelOptions(1)
        {
            FullMode = BoundedChannelFullMode.DropOldest
        });
        _workerTask = Task.Run(WorkerLoop);
    }

    public void Signal()
    {
        if (!_isDisposed)
        {
            _signal.Writer.TryWrite(true);
        }
    }

    private async Task WorkerLoop()
    {
        var changes = new List<Change>();

        try
        {
            while (!_cts.Token.IsCancellationRequested)
            {
                await _signal.Reader.WaitToReadAsync(_cts.Token);

                while (_signal.Reader.TryRead(out _)) { }

                while (_queue.TryDequeue(out var path, out _))
                {
                    if (_cts.Token.IsCancellationRequested)
                        break;

                    try
                    {
                        var result = await _computeAsync(path);

                        if (result.HasChanged)
                        {
                            changes.Add(Change.Computed(path, result.OldValue, result.NewValue));
                        }
                    }
                    catch (Exception ex)
                    {
                        changes.Add(new Change
                        {
                            Path = path,
                            Kind = ChangeKind.Computed,
                            OldValue = null,
                            NewValue = ex
                        });
                    }
                }

                if (changes.Count > 0)
                {
                    _onChanges(changes.ToList());
                    changes.Clear();
                }
            }
        }
        catch (OperationCanceledException)
        {
            // Expected on dispose
        }
    }

    public void Dispose()
    {
        if (_isDisposed)
            return;

        _isDisposed = true;
        
        _signal.Writer.Complete();
        
        try
        {
            _cts.Cancel();
        }
        catch (ObjectDisposedException)
        {
            // Already disposed
        }

        try
        {
            _workerTask.Wait(TimeSpan.FromSeconds(1));
        }
        catch (AggregateException)
        {
            // Task cancelled
        }

        _cts.Dispose();
    }
}

/// <summary>
/// Result of a computation.
/// </summary>
public readonly record struct ComputeResult
{
    public required bool HasChanged { get; init; }
    public object? OldValue { get; init; }
    public object? NewValue { get; init; }

    public static ComputeResult Unchanged() => new() { HasChanged = false };

    public static ComputeResult Changed(object? oldValue, object? newValue) => new()
    {
        HasChanged = true,
        OldValue = oldValue,
        NewValue = newValue
    };
}