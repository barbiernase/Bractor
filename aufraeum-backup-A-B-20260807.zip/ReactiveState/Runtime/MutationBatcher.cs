namespace ReactiveState.Runtime;

using System.Threading.Channels;

/// <summary>
/// Batches mutations together to reduce computation overhead.
/// </summary>
public sealed class MutationBatcher : IDisposable
{
    private readonly Channel<Action> _mutations;
    private readonly Channel<IReadOnlyList<Action>> _batches;
    private readonly TimeSpan _debounceTime;
    private readonly CancellationTokenSource _cts;
    private readonly Task _batcherTask;
    private bool _isDisposed;

    public MutationBatcher(TimeSpan? debounceTime = null)
    {
        _debounceTime = debounceTime ?? TimeSpan.FromMilliseconds(16);
        _mutations = Channel.CreateUnbounded<Action>(new UnboundedChannelOptions
        {
            SingleReader = true,
            SingleWriter = false
        });
        _batches = Channel.CreateUnbounded<IReadOnlyList<Action>>(new UnboundedChannelOptions
        {
            SingleReader = true,
            SingleWriter = true
        });
        _cts = new CancellationTokenSource();
        _batcherTask = Task.Run(BatcherLoop);
    }

    public ChannelReader<IReadOnlyList<Action>> Batches => _batches.Reader;

    public void QueueMutation(Action mutation)
    {
        if (!_isDisposed)
        {
            _mutations.Writer.TryWrite(mutation);
        }
    }

    public async ValueTask QueueMutationAsync(Action mutation)
    {
        if (!_isDisposed)
        {
            await _mutations.Writer.WriteAsync(mutation);
        }
    }

    private async Task BatcherLoop()
    {
        var batch = new List<Action>();
        var reader = _mutations.Reader;

        try
        {
            while (!_cts.Token.IsCancellationRequested)
            {
                if (await reader.WaitToReadAsync(_cts.Token))
                {
                    while (reader.TryRead(out var mutation))
                    {
                        batch.Add(mutation);
                    }

                    try
                    {
                        await Task.Delay(_debounceTime, _cts.Token);
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }

                    while (reader.TryRead(out var mutation))
                    {
                        batch.Add(mutation);
                    }

                    if (batch.Count > 0)
                    {
                        await _batches.Writer.WriteAsync(batch.ToList(), _cts.Token);
                        batch.Clear();
                    }
                }
            }
        }
        catch (OperationCanceledException)
        {
            // Expected on dispose
        }
        finally
        {
            _batches.Writer.Complete();
        }
    }

    public void Dispose()
    {
        if (_isDisposed)
            return;

        _isDisposed = true;
        
        _mutations.Writer.Complete();
        
        try
        {
            _cts.Cancel();
        }
        catch (ObjectDisposedException)
        {
            // Already disposed, ignore
        }
        
        try
        {
            _batcherTask.Wait(TimeSpan.FromSeconds(1));
        }
        catch (AggregateException)
        {
            // Task may have been cancelled
        }
        
        _cts.Dispose();
    }
}