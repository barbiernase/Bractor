namespace ReactiveState.Runtime;

/// <summary>
/// A priority queue for computed properties, sorted by level.
/// Lower levels are dequeued first (correct computation order).
/// </summary>
public sealed class ComputeQueue
{
    private readonly PriorityQueue<string, int> _queue = new();
    private readonly HashSet<string> _enqueued = new(StringComparer.Ordinal);
    private readonly object _lock = new();

    /// <summary>
    /// Number of items in the queue.
    /// </summary>
    public int Count
    {
        get
        {
            lock (_lock)
            {
                return _queue.Count;
            }
        }
    }

    /// <summary>
    /// Whether the queue is empty.
    /// </summary>
    public bool IsEmpty => Count == 0;

    /// <summary>
    /// Enqueues a path for computation if not already enqueued.
    /// </summary>
    /// <param name="path">The property path.</param>
    /// <param name="level">The computation level (priority).</param>
    /// <returns>True if enqueued, false if already in queue.</returns>
    public bool Enqueue(string path, int level)
    {
        lock (_lock)
        {
            if (_enqueued.Add(path))
            {
                _queue.Enqueue(path, level);
                return true;
            }
            return false;
        }
    }

    /// <summary>
    /// Enqueues multiple paths for computation.
    /// </summary>
    public int EnqueueRange(IEnumerable<(string Path, int Level)> items)
    {
        lock (_lock)
        {
            var count = 0;
            foreach (var (path, level) in items)
            {
                if (_enqueued.Add(path))
                {
                    _queue.Enqueue(path, level);
                    count++;
                }
            }
            return count;
        }
    }

    /// <summary>
    /// Tries to dequeue the next path (lowest level first).
    /// </summary>
    public bool TryDequeue(out string path, out int level)
    {
        lock (_lock)
        {
            if (_queue.TryDequeue(out path!, out level))
            {
                _enqueued.Remove(path);
                return true;
            }
            path = default!;
            level = default;
            return false;
        }
    }

    /// <summary>
    /// Dequeues all items, returning them sorted by level.
    /// </summary>
    public IReadOnlyList<(string Path, int Level)> DequeueAll()
    {
        lock (_lock)
        {
            var result = new List<(string, int)>(_queue.Count);
            while (_queue.TryDequeue(out var path, out var level))
            {
                result.Add((path, level));
            }
            _enqueued.Clear();
            return result;
        }
    }

    /// <summary>
    /// Clears the queue.
    /// </summary>
    public void Clear()
    {
        lock (_lock)
        {
            _queue.Clear();
            _enqueued.Clear();
        }
    }

    /// <summary>
    /// Checks if a path is currently enqueued.
    /// </summary>
    public bool Contains(string path)
    {
        lock (_lock)
        {
            return _enqueued.Contains(path);
        }
    }
}