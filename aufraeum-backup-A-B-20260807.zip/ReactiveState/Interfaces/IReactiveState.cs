namespace ReactiveState;

/// <summary>
/// Interface implemented by all generated state classes.
/// Provides access to the underlying store connection.
/// </summary>
public interface IReactiveState : IConnectableState
{
    /// <summary>
    /// Whether the state is connected to a store.
    /// </summary>
    bool IsConnected { get; }
    
    /// <summary>
    /// The store this state is connected to (null if not connected).
    /// </summary>
    IStateStore? Store { get; }
}