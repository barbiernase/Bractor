namespace ReactiveState.Collections;

/// <summary>
/// Internal interface for items that can be attached to a state store.
/// Implemented by generated [Reactive] classes.
/// </summary>
public interface IReactiveItem : IIdentifiable
{
    /// <summary>
    /// Connects the item to a state store with a path prefix.
    /// </summary>
    void __Connect(IStateStore store, string pathPrefix);

    /// <summary>
    /// Disconnects the item from its state store.
    /// </summary>
    void __Disconnect();
}