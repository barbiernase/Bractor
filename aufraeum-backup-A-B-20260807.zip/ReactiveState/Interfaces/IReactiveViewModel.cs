namespace ReactiveState;

using System.ComponentModel;

/// <summary>
/// Interface implemented by all generated view model classes.
/// </summary>
public interface IReactiveViewModel : INotifyPropertyChanged
{
    /// <summary>
    /// Attaches the view model to a state store, starting subscriptions.
    /// </summary>
    void Attach(IStateStore store);

    /// <summary>
    /// Detaches the view model from its store, stopping subscriptions.
    /// </summary>
    void Detach();

    /// <summary>
    /// Whether the view model is currently attached.
    /// </summary>
    bool IsAttached { get; }
    
    /// <summary>
    /// The store this view model is attached to (null if not attached).
    /// </summary>
    IStateStore? Store { get; }
}

