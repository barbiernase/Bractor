namespace ReactiveState.Graph;

/// <summary>
/// The kind of a graph node.
/// </summary>
public enum NodeKind : byte
{
    /// <summary>
    /// A tracked property (directly mutable, Level 0).
    /// </summary>
    Tracked = 0,

    /// <summary>
    /// A computed property (derived from other properties, Level 1+).
    /// </summary>
    Computed = 1
}