namespace ReactiveState.Graph;

/// <summary>
/// A node in the dependency graph representing a property.
/// </summary>
public readonly record struct GraphNode
{
    /// <summary>
    /// The path of the property (e.g. "UserName", "Todos[*].Title").
    /// </summary>
    public required string Path { get; init; }

    /// <summary>
    /// Whether this is a tracked or computed property.
    /// </summary>
    public required NodeKind Kind { get; init; }

    /// <summary>
    /// The computation level. Tracked = 0, Computed = max(dependencies) + 1.
    /// </summary>
    public required int Level { get; init; }

    /// <summary>
    /// Whether the computation is async (only relevant for Computed).
    /// </summary>
    public bool IsAsync { get; init; }

    // ═══════════════════════════════════════════════════════════
    //  Helpers
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// True if this is a tracked property.
    /// </summary>
    public bool IsTracked => Kind == NodeKind.Tracked;

    /// <summary>
    /// True if this is a computed property.
    /// </summary>
    public bool IsComputed => Kind == NodeKind.Computed;

    /// <summary>
    /// True if this is a template path (contains [*]).
    /// </summary>
    public bool IsTemplate => Path.Contains("[*]");

    /// <summary>
    /// True if this is an instance path (contains [id:...]).
    /// </summary>
    public bool IsInstance => Path.Contains("[id:");

    /// <summary>
    /// Converts a template path to an instance path.
    /// "Todos[*].Title" + "abc" -> "Todos[id:abc].Title"
    /// </summary>
    public string ToInstancePath(string id)
    {
        if (!IsTemplate)
            throw new InvalidOperationException($"Path '{Path}' is not a template.");

        return Path.Replace("[*]", $"[id:{id}]");
    }

    /// <summary>
    /// Converts an instance path to a template path.
    /// "Todos[id:abc].Title" -> "Todos[*].Title"
    /// </summary>
    public static string ToTemplatePath(string instancePath)
    {
        // Replace [id:...] with [*]
        var start = instancePath.IndexOf("[id:", StringComparison.Ordinal);
        if (start < 0) return instancePath;

        var end = instancePath.IndexOf(']', start);
        if (end < 0) return instancePath;

        return string.Concat(instancePath.AsSpan(0, start), "[*]", instancePath.AsSpan(end + 1));
    }

    // ═══════════════════════════════════════════════════════════
    //  Factories
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Creates a tracked node (Level 0).
    /// </summary>
    public static GraphNode Tracked(string path) => new()
    {
        Path = path,
        Kind = NodeKind.Tracked,
        Level = 0,
        IsAsync = false
    };

    /// <summary>
    /// Creates a computed node.
    /// </summary>
    public static GraphNode Computed(string path, int level, bool isAsync = false) => new()
    {
        Path = path,
        Kind = NodeKind.Computed,
        Level = level,
        IsAsync = isAsync
    };

    // ═══════════════════════════════════════════════════════════
    //  ToString
    // ═══════════════════════════════════════════════════════════

    public override string ToString()
    {
        var asyncMarker = IsAsync ? " (async)" : "";
        return $"{Kind}[{Level}]: {Path}{asyncMarker}";
    }
}