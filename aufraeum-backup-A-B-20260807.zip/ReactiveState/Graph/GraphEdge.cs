namespace ReactiveState.Graph;

/// <summary>
/// An edge in the dependency graph representing a dependency relationship.
/// "To depends on From" or "When From changes, To must recompute".
/// </summary>
public readonly record struct GraphEdge
{
    /// <summary>
    /// The source path (the dependency).
    /// </summary>
    public required string From { get; init; }

    /// <summary>
    /// The target path (the dependent).
    /// </summary>
    public required string To { get; init; }

    // ═══════════════════════════════════════════════════════════
    //  Factories
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Creates an edge: To depends on From.
    /// </summary>
    public static GraphEdge Create(string from, string to) => new()
    {
        From = from,
        To = to
    };

    /// <summary>
    /// Creates an edge using arrow syntax (more readable).
    /// DependsOn("Count", "DoubledCount") means DoubledCount depends on Count.
    /// </summary>
    public static GraphEdge DependsOn(string dependency, string dependent) => new()
    {
        From = dependency,
        To = dependent
    };

    // ═══════════════════════════════════════════════════════════
    //  Helpers
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// True if this edge involves template paths.
    /// </summary>
    public bool IsTemplate => From.Contains("[*]") || To.Contains("[*]");

    /// <summary>
    /// Converts a template edge to an instance edge.
    /// </summary>
    public GraphEdge ToInstanceEdge(string id)
    {
        return new GraphEdge
        {
            From = From.Replace("[*]", $"[id:{id}]"),
            To = To.Replace("[*]", $"[id:{id}]")
        };
    }

    // ═══════════════════════════════════════════════════════════
    //  ToString
    // ═══════════════════════════════════════════════════════════

    public override string ToString() => $"{From} → {To}";
}