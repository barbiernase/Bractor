namespace ReactiveState.Graph;

/// <summary>
/// The dependency graph that describes relationships between properties.
/// Immutable after construction.
/// </summary>
public sealed class DependencyGraph
{
    // Node lookup by path
    private readonly Dictionary<string, GraphNode> _nodes;
    
    // Forward edges: From → [To, To, ...]
    // "When From changes, all To must recompute"
    private readonly Dictionary<string, List<string>> _dependents;
    
    // Reverse edges: To → [From, From, ...]
    // "To depends on all From"
    private readonly Dictionary<string, List<string>> _dependencies;
    
    // Template paths (for collection items)
    private readonly List<string> _templatePaths;

    // ═══════════════════════════════════════════════════════════
    //  Construction
    // ═══════════════════════════════════════════════════════════

    public DependencyGraph(
        IEnumerable<GraphNode> nodes,
        IEnumerable<GraphEdge> edges)
    {
        _nodes = new Dictionary<string, GraphNode>(StringComparer.Ordinal);
        _dependents = new Dictionary<string, List<string>>(StringComparer.Ordinal);
        _dependencies = new Dictionary<string, List<string>>(StringComparer.Ordinal);
        _templatePaths = new List<string>();

        // Index nodes
        foreach (var node in nodes)
        {
            _nodes[node.Path] = node;
            
            if (node.IsTemplate)
            {
                _templatePaths.Add(node.Path);
            }
        }

        // Index edges
        foreach (var edge in edges)
        {
            // Forward: From → To
            if (!_dependents.TryGetValue(edge.From, out var dependentList))
            {
                dependentList = new List<string>();
                _dependents[edge.From] = dependentList;
            }
            dependentList.Add(edge.To);

            // Reverse: To → From
            if (!_dependencies.TryGetValue(edge.To, out var dependencyList))
            {
                dependencyList = new List<string>();
                _dependencies[edge.To] = dependencyList;
            }
            dependencyList.Add(edge.From);
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Public Properties
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// All nodes in the graph.
    /// </summary>
    public IReadOnlyCollection<GraphNode> Nodes => _nodes.Values;

    /// <summary>
    /// All template paths in the graph.
    /// </summary>
    public IReadOnlyList<string> TemplatePaths => _templatePaths;

    /// <summary>
    /// Gets a node by path, or null if not found.
    /// </summary>
    public GraphNode? GetNode(string path)
    {
        return _nodes.TryGetValue(path, out var node) ? node : null;
    }

    /// <summary>
    /// Gets a node by path. Throws if not found.
    /// </summary>
    public GraphNode GetNodeRequired(string path)
    {
        if (!_nodes.TryGetValue(path, out var node))
            throw new KeyNotFoundException($"Node '{path}' not found in graph.");
        return node;
    }

    /// <summary>
    /// Checks if a node exists.
    /// </summary>
    public bool HasNode(string path) => _nodes.ContainsKey(path);

    // ═══════════════════════════════════════════════════════════
    //  Direct Relationships
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Gets the direct dependents of a path (one level).
    /// "What directly depends on this?"
    /// </summary>
    public IReadOnlyList<string> GetDirectDependents(string path)
    {
        if (_dependents.TryGetValue(path, out var list))
            return list;

        // Try template match for instance paths
        var templatePath = PropertyPath.ToTemplate(path);
        if (templatePath != path && _dependents.TryGetValue(templatePath, out list))
            return list;

        return Array.Empty<string>();
    }

    /// <summary>
    /// Gets the direct dependencies of a path (one level).
    /// "What does this directly depend on?"
    /// </summary>
    public IReadOnlyList<string> GetDirectDependencies(string path)
    {
        if (_dependencies.TryGetValue(path, out var list))
            return list;

        // Try template match for instance paths
        var templatePath = PropertyPath.ToTemplate(path);
        if (templatePath != path && _dependencies.TryGetValue(templatePath, out list))
            return list;

        return Array.Empty<string>();
    }

    // ═══════════════════════════════════════════════════════════
    //  Transitive Traversal
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Gets all paths affected when the given path changes (transitive).
    /// Results are sorted by level (lowest first) for correct computation order.
    /// </summary>
    public IReadOnlyList<string> GetAffected(string changedPath)
    {
        var affected = new HashSet<string>(StringComparer.Ordinal);
        var queue = new Queue<string>();

        // Handle instance vs template paths
        var templatePath = PropertyPath.ToTemplate(changedPath);
        var id = PropertyPath.ExtractId(changedPath);

        // Start with direct dependents
        EnqueueDependents(changedPath, queue, affected, id);
        
        if (templatePath != changedPath)
        {
            EnqueueDependents(templatePath, queue, affected, id);
        }

        // BFS traversal
        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            EnqueueDependents(current, queue, affected, id);
            
            // Also check template version
            var currentTemplate = PropertyPath.ToTemplate(current);
            if (currentTemplate != current)
            {
                EnqueueDependents(currentTemplate, queue, affected, id);
            }
        }

        // Sort by level
        return SortByLevel(affected);
    }

    /// <summary>
    /// Gets all paths that the given path depends on (transitive).
    /// </summary>
    public IReadOnlyList<string> GetAllDependencies(string path)
    {
        var dependencies = new HashSet<string>(StringComparer.Ordinal);
        var queue = new Queue<string>();

        // Start with direct dependencies
        foreach (var dep in GetDirectDependencies(path))
        {
            if (dependencies.Add(dep))
                queue.Enqueue(dep);
        }

        // BFS traversal
        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            foreach (var dep in GetDirectDependencies(current))
            {
                if (dependencies.Add(dep))
                    queue.Enqueue(dep);
            }
        }

        return SortByLevel(dependencies);
    }

    // ═══════════════════════════════════════════════════════════
    //  Collection/Template Support
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Gets all affected paths when a collection itself changes (add/remove).
    /// </summary>
    public IReadOnlyList<string> GetAffectedByCollectionChange(string collectionPath)
    {
        return GetAffected(collectionPath);
    }

    /// <summary>
    /// Gets all affected paths when a collection item property changes.
    /// Converts template results to instance paths.
    /// </summary>
    public IReadOnlyList<string> GetAffectedByItemChange(
        string collectionPath,
        string itemId,
        string propertyName)
    {
        // Build the instance path: "Todos[id:abc].Title"
        var instancePath = $"{collectionPath}[id:{itemId}].{propertyName}";
        
        // Get affected (will match against template paths)
        var templateAffected = GetAffected(instancePath);

        // Convert template results back to instance paths
        var result = new List<string>(templateAffected.Count);
        foreach (var path in templateAffected)
        {
            if (PropertyPath.IsTemplate(path))
            {
                result.Add(PropertyPath.ToInstance(path, itemId));
            }
            else
            {
                result.Add(path);
            }
        }

        return result;
    }

    /// <summary>
    /// Finds the template path that matches an instance path.
    /// </summary>
    public string? FindMatchingTemplate(string instancePath)
    {
        if (!PropertyPath.IsInstance(instancePath))
            return null;

        var templatePath = PropertyPath.ToTemplate(instancePath);
        return _nodes.ContainsKey(templatePath) ? templatePath : null;
    }

    // ═══════════════════════════════════════════════════════════
    //  Level Queries
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Gets the level of a path. Returns 0 for unknown paths.
    /// </summary>
    public int GetLevel(string path)
    {
        if (_nodes.TryGetValue(path, out var node))
            return node.Level;

        // Try template
        var templatePath = PropertyPath.ToTemplate(path);
        if (templatePath != path && _nodes.TryGetValue(templatePath, out node))
            return node.Level;

        return 0;
    }

    /// <summary>
    /// Gets all paths at a specific level.
    /// </summary>
    public IReadOnlyList<string> GetPathsAtLevel(int level)
    {
        return _nodes.Values
            .Where(n => n.Level == level)
            .Select(n => n.Path)
            .ToList();
    }

    /// <summary>
    /// Gets the maximum level in the graph.
    /// </summary>
    public int MaxLevel => _nodes.Values.Max(n => n.Level);

    // ═══════════════════════════════════════════════════════════
    //  Validation
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Validates the graph for cycles and correct levels.
    /// Returns a list of errors (empty if valid).
    /// </summary>
    public IReadOnlyList<string> Validate()
    {
        var errors = new List<string>();

        // Check for cycles
        var visited = new HashSet<string>(StringComparer.Ordinal);
        var inStack = new HashSet<string>(StringComparer.Ordinal);

        foreach (var node in _nodes.Keys)
        {
            if (HasCycle(node, visited, inStack, out var cyclePath))
            {
                errors.Add($"Cycle detected: {cyclePath}");
            }
        }

        // Check levels are consistent
        foreach (var node in _nodes.Values)
        {
            if (node.Kind == NodeKind.Computed)
            {
                var deps = GetDirectDependencies(node.Path);
                if (deps.Count > 0)
                {
                    var maxDepLevel = deps.Max(d => GetLevel(d));
                    if (node.Level <= maxDepLevel)
                    {
                        errors.Add(
                            $"Invalid level for '{node.Path}': Level {node.Level} " +
                            $"but depends on level {maxDepLevel}");
                    }
                }
            }
        }

        return errors;
    }

    // ═══════════════════════════════════════════════════════════
    //  Private Helpers
    // ═══════════════════════════════════════════════════════════

    private void EnqueueDependents(
        string path,
        Queue<string> queue,
        HashSet<string> visited,
        string? itemId)
    {
        if (!_dependents.TryGetValue(path, out var dependents))
            return;

        foreach (var dep in dependents)
        {
            // Convert template to instance if we have an itemId
            var resolvedPath = dep;
            if (itemId != null && PropertyPath.IsTemplate(dep))
            {
                resolvedPath = PropertyPath.ToInstance(dep, itemId);
            }

            if (visited.Add(resolvedPath))
            {
                queue.Enqueue(resolvedPath);
            }
        }
    }

    private IReadOnlyList<string> SortByLevel(IEnumerable<string> paths)
    {
        return paths
            .OrderBy(p => GetLevel(p))
            .ThenBy(p => p, StringComparer.Ordinal)
            .ToList();
    }

    private bool HasCycle(
        string node,
        HashSet<string> visited,
        HashSet<string> inStack,
        out string cyclePath)
    {
        cyclePath = "";

        if (inStack.Contains(node))
        {
            cyclePath = node;
            return true;
        }

        if (visited.Contains(node))
            return false;

        visited.Add(node);
        inStack.Add(node);

        foreach (var dep in GetDirectDependents(node))
        {
            if (HasCycle(dep, visited, inStack, out cyclePath))
            {
                cyclePath = $"{node} → {cyclePath}";
                return true;
            }
        }

        inStack.Remove(node);
        return false;
    }
}