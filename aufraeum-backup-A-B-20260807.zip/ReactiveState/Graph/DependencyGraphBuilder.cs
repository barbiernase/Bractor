namespace ReactiveState.Graph;

/// <summary>
/// Builder for constructing a DependencyGraph.
/// </summary>
public sealed class DependencyGraphBuilder
{
    private readonly List<GraphNode> _nodes = new();
    private readonly List<GraphEdge> _edges = new();
    private readonly Dictionary<string, int> _levels = new(StringComparer.Ordinal);

    // ═══════════════════════════════════════════════════════════
    //  Adding Nodes
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Adds a tracked property (Level 0).
    /// </summary>
    public DependencyGraphBuilder AddTracked(string path)
    {
        _nodes.Add(GraphNode.Tracked(path));
        _levels[path] = 0;
        return this;
    }

    /// <summary>
    /// Adds multiple tracked properties.
    /// </summary>
    public DependencyGraphBuilder AddTracked(params string[] paths)
    {
        foreach (var path in paths)
            AddTracked(path);
        return this;
    }

    /// <summary>
    /// Adds a computed property. Level is calculated automatically.
    /// </summary>
    public DependencyGraphBuilder AddComputed(
        string path,
        bool isAsync = false,
        params string[] dependsOn)
    {
        // Calculate level based on dependencies
        var level = 1;
        foreach (var dep in dependsOn)
        {
            if (_levels.TryGetValue(dep, out var depLevel))
            {
                level = Math.Max(level, depLevel + 1);
            }
            
            // Add edge
            _edges.Add(GraphEdge.Create(dep, path));
        }

        _nodes.Add(GraphNode.Computed(path, level, isAsync));
        _levels[path] = level;
        return this;
    }

    /// <summary>
    /// Adds a dependency edge manually.
    /// </summary>
    public DependencyGraphBuilder AddEdge(string from, string to)
    {
        _edges.Add(GraphEdge.Create(from, to));
        return this;
    }

    // ═══════════════════════════════════════════════════════════
    //  Building
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Builds the dependency graph.
    /// </summary>
    public DependencyGraph Build()
    {
        return new DependencyGraph(_nodes, _edges);
    }

    /// <summary>
    /// Builds and validates the graph. Throws if invalid.
    /// </summary>
    public DependencyGraph BuildAndValidate()
    {
        var graph = Build();
        var errors = graph.Validate();
        
        if (errors.Count > 0)
        {
            throw new InvalidOperationException(
                $"Invalid dependency graph:\n{string.Join("\n", errors)}");
        }
        
        return graph;
    }
}