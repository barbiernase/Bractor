namespace ReactiveState.Graph;

/// <summary>
/// Utilities for working with property paths.
/// </summary>
public static class PropertyPath
{
    /// <summary>
    /// The wildcard used in template paths.
    /// </summary>
    public const string Wildcard = "[*]";

    /// <summary>
    /// The prefix for ID-based paths.
    /// </summary>
    public const string IdPrefix = "[id:";

    /// <summary>
    /// Checks if a path is a template (contains [*]).
    /// </summary>
    public static bool IsTemplate(string path) => path.Contains(Wildcard);

    /// <summary>
    /// Checks if a path is an instance (contains [id:...]).
    /// </summary>
    public static bool IsInstance(string path) => path.Contains(IdPrefix);

    /// <summary>
    /// Converts an instance path to a template path.
    /// "Todos[id:abc].Title" -> "Todos[*].Title"
    /// </summary>
    public static string ToTemplate(string instancePath)
    {
        if (!IsInstance(instancePath))
            return instancePath;

        var start = instancePath.IndexOf(IdPrefix, StringComparison.Ordinal);
        var end = instancePath.IndexOf(']', start);

        if (start < 0 || end < 0)
            return instancePath;

        return string.Concat(
            instancePath.AsSpan(0, start),
            Wildcard,
            instancePath.AsSpan(end + 1)
        );
    }

    /// <summary>
    /// Converts a template path to an instance path.
    /// "Todos[*].Title" + "abc" -> "Todos[id:abc].Title"
    /// </summary>
    public static string ToInstance(string templatePath, string id)
    {
        return templatePath.Replace(Wildcard, $"[id:{id}]");
    }

    /// <summary>
    /// Extracts the ID from an instance path.
    /// "Todos[id:abc].Title" -> "abc"
    /// </summary>
    public static string? ExtractId(string instancePath)
    {
        var start = instancePath.IndexOf(IdPrefix, StringComparison.Ordinal);
        if (start < 0) return null;

        start += IdPrefix.Length;
        var end = instancePath.IndexOf(']', start);

        return end > start ? instancePath[start..end] : null;
    }

    /// <summary>
    /// Extracts the collection path (before the bracket).
    /// "Todos[id:abc].Title" -> "Todos"
    /// "Todos[*].Title" -> "Todos"
    /// </summary>
    public static string? ExtractCollectionPath(string path)
    {
        var bracketIndex = path.IndexOf('[');
        return bracketIndex > 0 ? path[..bracketIndex] : null;
    }

    /// <summary>
    /// Extracts the property path after the item.
    /// "Todos[id:abc].Title" -> "Title"
    /// "Todos[id:abc].Address.City" -> "Address.City"
    /// </summary>
    public static string? ExtractItemProperty(string path)
    {
        var bracketEnd = path.IndexOf(']');
        if (bracketEnd < 0 || bracketEnd >= path.Length - 1)
            return null;

        // Skip "]."
        return path[(bracketEnd + 2)..];
    }

    /// <summary>
    /// Combines a parent path with a property name.
    /// "Todos[id:abc]" + "Title" -> "Todos[id:abc].Title"
    /// </summary>
    public static string Combine(string parent, string property)
    {
        if (string.IsNullOrEmpty(parent))
            return property;

        return $"{parent}.{property}";
    }

    /// <summary>
    /// Gets the parent path.
    /// "Todos[id:abc].Title" -> "Todos[id:abc]"
    /// "Address.City" -> "Address"
    /// "UserName" -> null
    /// </summary>
    public static string? GetParent(string path)
    {
        var lastDot = path.LastIndexOf('.');
        return lastDot > 0 ? path[..lastDot] : null;
    }

    /// <summary>
    /// Gets the property name (last segment).
    /// "Todos[id:abc].Title" -> "Title"
    /// "Address.City" -> "City"
    /// "UserName" -> "UserName"
    /// </summary>
    public static string GetPropertyName(string path)
    {
        var lastDot = path.LastIndexOf('.');
        return lastDot >= 0 ? path[(lastDot + 1)..] : path;
    }

    /// <summary>
    /// Checks if an instance path matches a template path.
    /// "Todos[id:abc].Title" matches "Todos[*].Title" -> true
    /// "Todos[id:abc].Title" matches "Todos[*].Name" -> false
    /// </summary>
    public static bool Matches(string instancePath, string templatePath)
    {
        if (!IsTemplate(templatePath))
            return string.Equals(instancePath, templatePath, StringComparison.Ordinal);

        // Convert instance to template and compare
        var instanceAsTemplate = ToTemplate(instancePath);
        return string.Equals(instanceAsTemplate, templatePath, StringComparison.Ordinal);
    }

    /// <summary>
    /// Checks if a path is a child of another path.
    /// "Address.City" is child of "Address" -> true
    /// "Address" is child of "Address" -> false
    /// </summary>
    public static bool IsChildOf(string path, string parentPath)
    {
        return path.StartsWith(parentPath + ".", StringComparison.Ordinal)
            || path.StartsWith(parentPath + "[", StringComparison.Ordinal);
    }

    /// <summary>
    /// Checks if a path is the same as or a child of another path.
    /// </summary>
    public static bool IsSameOrChildOf(string path, string parentPath)
    {
        return string.Equals(path, parentPath, StringComparison.Ordinal)
            || IsChildOf(path, parentPath);
    }
}