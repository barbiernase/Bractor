namespace ReactiveState;

/// <summary>
/// The kind of change that occurred.
/// </summary>
public enum ChangeKind : byte
{
    /// <summary>
    /// A property was set to a new value.
    /// </summary>
    Set = 0,

    /// <summary>
    /// An item was added to a collection.
    /// </summary>
    Add = 1,

    /// <summary>
    /// An item was removed from a collection.
    /// </summary>
    Remove = 2,

    /// <summary>
    /// An item in a collection was replaced.
    /// </summary>
    Replace = 3,

    /// <summary>
    /// A collection was cleared.
    /// </summary>
    Clear = 4,

    /// <summary>
    /// A computed property was recalculated.
    /// </summary>
    Computed = 5
}