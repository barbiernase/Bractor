namespace ReactiveState;

/// <summary>
/// Represents a value that may be pending, ready, or failed.
/// </summary>
public readonly struct LazyValue<T> : IEquatable<LazyValue<T>>
{
    private readonly T? _value;
    private readonly Exception? _error;
    private readonly LazyState _state;

    private LazyValue(LazyState state, T? value, Exception? error)
    {
        _state = state;
        _value = value;
        _error = error;
    }

    // ═══════════════════════════════════════════════════════════
    //  State Checks
    // ═══════════════════════════════════════════════════════════

    public bool IsPending => _state == LazyState.Pending;
    public bool IsReady => _state == LazyState.Ready;
    public bool IsFailed => _state == LazyState.Failed;

    // ═══════════════════════════════════════════════════════════
    //  Value Access
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Gets the value. Throws if Pending or Failed.
    /// </summary>
    public T Value => _state switch
    {
        LazyState.Ready => _value!,
        LazyState.Failed => throw new InvalidOperationException(
            "Cannot access Value of a failed LazyValue.", _error),
        LazyState.Pending => throw new InvalidOperationException(
            "Cannot access Value of a pending LazyValue."),
        _ => throw new InvalidOperationException("Invalid state.")
    };

    /// <summary>
    /// Gets the value or default if not Ready.
    /// </summary>
    public T? ValueOrDefault => IsReady ? _value : default;

    /// <summary>
    /// Gets the error. Throws if not Failed.
    /// </summary>
    public Exception Error => _state == LazyState.Failed
        ? _error!
        : throw new InvalidOperationException("LazyValue is not in Failed state.");

    /// <summary>
    /// Tries to get the value.
    /// </summary>
    public bool TryGetValue(out T value)
    {
        if (IsReady)
        {
            value = _value!;
            return true;
        }
        value = default!;
        return false;
    }

    /// <summary>
    /// Tries to get the error.
    /// </summary>
    public bool TryGetError(out Exception error)
    {
        if (IsFailed)
        {
            error = _error!;
            return true;
        }
        error = default!;
        return false;
    }

    // ═══════════════════════════════════════════════════════════
    //  Factories
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// A pending LazyValue.
    /// </summary>
    public static LazyValue<T> Pending => new(LazyState.Pending, default, null);

    /// <summary>
    /// Creates a ready LazyValue with the given value.
    /// </summary>
    public static LazyValue<T> Ready(T value) => new(LazyState.Ready, value, null);

    /// <summary>
    /// Creates a failed LazyValue with the given exception.
    /// </summary>
    public static LazyValue<T> Failed(Exception error)
    {
        ArgumentNullException.ThrowIfNull(error);
        return new(LazyState.Failed, default, error);
    }

    // ═══════════════════════════════════════════════════════════
    //  Pattern Matching
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Pattern matches on the state.
    /// </summary>
    public TResult Match<TResult>(
        Func<TResult> pending,
        Func<T, TResult> ready,
        Func<Exception, TResult> failed)
    {
        ArgumentNullException.ThrowIfNull(pending);
        ArgumentNullException.ThrowIfNull(ready);
        ArgumentNullException.ThrowIfNull(failed);

        return _state switch
        {
            LazyState.Pending => pending(),
            LazyState.Ready => ready(_value!),
            LazyState.Failed => failed(_error!),
            _ => throw new InvalidOperationException("Invalid state.")
        };
    }

    /// <summary>
    /// Pattern matches with an action (no return value).
    /// </summary>
    public void Switch(
        Action pending,
        Action<T> ready,
        Action<Exception> failed)
    {
        ArgumentNullException.ThrowIfNull(pending);
        ArgumentNullException.ThrowIfNull(ready);
        ArgumentNullException.ThrowIfNull(failed);

        switch (_state)
        {
            case LazyState.Pending:
                pending();
                break;
            case LazyState.Ready:
                ready(_value!);
                break;
            case LazyState.Failed:
                failed(_error!);
                break;
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Transformations
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Maps the value if Ready, preserves Pending/Failed.
    /// </summary>
    public LazyValue<TResult> Select<TResult>(Func<T, TResult> selector)
    {
        ArgumentNullException.ThrowIfNull(selector);

        return _state switch
        {
            LazyState.Ready => LazyValue<TResult>.Ready(selector(_value!)),
            LazyState.Failed => LazyValue<TResult>.Failed(_error!),
            _ => LazyValue<TResult>.Pending
        };
    }

    /// <summary>
    /// Flat maps the value if Ready.
    /// </summary>
    public LazyValue<TResult> SelectMany<TResult>(Func<T, LazyValue<TResult>> selector)
    {
        ArgumentNullException.ThrowIfNull(selector);

        return _state switch
        {
            LazyState.Ready => selector(_value!),
            LazyState.Failed => LazyValue<TResult>.Failed(_error!),
            _ => LazyValue<TResult>.Pending
        };
    }

    /// <summary>
    /// Returns the value if Ready, otherwise the fallback.
    /// </summary>
    public T GetValueOr(T fallback) => IsReady ? _value! : fallback;

    /// <summary>
    /// Returns the value if Ready, otherwise invokes the fallback factory.
    /// </summary>
    public T GetValueOr(Func<T> fallbackFactory)
    {
        ArgumentNullException.ThrowIfNull(fallbackFactory);
        return IsReady ? _value! : fallbackFactory();
    }

    // ═══════════════════════════════════════════════════════════
    //  Equality
    // ═══════════════════════════════════════════════════════════

    public bool Equals(LazyValue<T> other)
    {
        if (_state != other._state)
            return false;

        return _state switch
        {
            LazyState.Pending => true,
            LazyState.Ready => EqualityComparer<T>.Default.Equals(_value, other._value),
            LazyState.Failed => ReferenceEquals(_error, other._error),
            _ => false
        };
    }

    public override bool Equals(object? obj) => obj is LazyValue<T> other && Equals(other);

    public override int GetHashCode() => _state switch
    {
        LazyState.Pending => 0,
        LazyState.Ready => HashCode.Combine(1, _value),
        LazyState.Failed => HashCode.Combine(2, _error?.GetHashCode() ?? 0),
        _ => -1
    };

    public static bool operator ==(LazyValue<T> left, LazyValue<T> right) => left.Equals(right);
    public static bool operator !=(LazyValue<T> left, LazyValue<T> right) => !left.Equals(right);

    // ═══════════════════════════════════════════════════════════
    //  ToString
    // ═══════════════════════════════════════════════════════════

    public override string ToString() => _state switch
    {
        LazyState.Pending => "Pending",
        LazyState.Ready => $"Ready({_value})",
        LazyState.Failed => $"Failed({_error?.GetType().Name}: {_error?.Message})",
        _ => "Invalid"
    };
}

/// <summary>
/// The state of a LazyValue.
/// </summary>
public enum LazyState : byte
{
    Pending = 0,
    Ready = 1,
    Failed = 2
}