namespace ReactiveState.Collections;

using ReactiveState.Runtime;

/// <summary>
/// Tracks changes for a collection and notifies the reactive core.
/// </summary>
internal sealed class CollectionChangeTracker
{
    private ReactiveCore? _core;
    private string? _path;

    /// <summary>
    /// Whether the tracker is attached to a core.
    /// </summary>
    public bool IsAttached => _core != null;

    /// <summary>
    /// The path of the collection.
    /// </summary>
    public string? Path => _path;

    /// <summary>
    /// Attaches to a reactive core.
    /// </summary>
    public void Attach(ReactiveCore core, string path)
    {
        _core = core;
        _path = path;
    }

    /// <summary>
    /// Detaches from the reactive core.
    /// </summary>
    public void Detach()
    {
        _core = null;
        _path = null;
    }

    /// <summary>
    /// Notifies that an item was added.
    /// </summary>
    public void NotifyAdded(object? item, string? itemId)
    {
        _core?.NotifyAdded(_path!, item, itemId);
    }

    /// <summary>
    /// Notifies that an item was removed.
    /// </summary>
    public void NotifyRemoved(object? item, string? itemId)
    {
        _core?.NotifyRemoved(_path!, item, itemId);
    }

    /// <summary>
    /// Notifies that the collection was cleared.
    /// </summary>
    public void NotifyCleared(int previousCount)
    {
        _core?.NotifyCleared(_path!, previousCount);
    }

    /// <summary>
    /// Notifies that an item property changed.
    /// </summary>
    public void NotifyItemChanged(string itemId, string propertyName, object? oldValue, object? newValue)
    {
        _core?.NotifyItemChanged(_path!, itemId, propertyName, oldValue, newValue);
    }
}