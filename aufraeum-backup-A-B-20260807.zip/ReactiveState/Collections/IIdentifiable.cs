namespace ReactiveState.Collections;

/// <summary>
/// Interface for items that can be identified by a string ID.
/// Required for items in TrackedList.
/// </summary>
public interface IIdentifiable
{
    /// <summary>
    /// The unique identifier for this item.
    /// </summary>
    string Id { get; }
}