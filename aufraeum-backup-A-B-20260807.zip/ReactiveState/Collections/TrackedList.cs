namespace ReactiveState.Collections;

using System.Collections;

/// <summary>
/// A list that tracks collection changes and notifies the state store.
/// Minimal API, maximum performance.
/// </summary>
public sealed class TrackedList<T> : IReadOnlyList<T>
    where T : class, IIdentifiable
{
    private readonly List<T> _items;
    private readonly Dictionary<string, T> _byId;
    
    private IStateStore? _store;
    private string? _path;

    // ═══════════════════════════════════════════════════════════
    //  Construction
    // ═══════════════════════════════════════════════════════════

    public TrackedList()
    {
        _items = new List<T>();
        _byId = new Dictionary<string, T>(StringComparer.Ordinal);
    }

    public TrackedList(int capacity)
    {
        _items = new List<T>(capacity);
        _byId = new Dictionary<string, T>(capacity, StringComparer.Ordinal);
    }

    // ═══════════════════════════════════════════════════════════
    //  Attachment
    // ═══════════════════════════════════════════════════════════

    public void Attach(IStateStore store, string path)
    {
        _store = store;
        _path = path;

        // Connect existing items
        foreach (var item in _items)
        {
            ConnectItem(item);
        }
    }

    public void Detach()
    {
        // Disconnect all items FIRST
        foreach (var item in _items)
        {
            DisconnectItem(item);
        }

        // THEN clear store reference
        _store = null;
        _path = null;
    }

    

    public bool IsAttached => _store != null;

    private void ConnectItem(T item)
    {
        if (_store != null && item is IReactiveItem reactiveItem)
        {
            var itemPath = $"{_path}[id:{item.Id}]";
            reactiveItem.__Connect(_store, itemPath);
        }
    }

    private void DisconnectItem(T item)
    {
        if (item is IReactiveItem reactiveItem)
        {
            reactiveItem.__Disconnect();
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Read Access
    // ═══════════════════════════════════════════════════════════

    public int Count => _items.Count;

    public T this[int index] => _items[index];

    public IReadOnlyList<T> Items => _items;

    public IEnumerator<T> GetEnumerator() => _items.GetEnumerator();

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

    // ═══════════════════════════════════════════════════════════
    //  ID-based Access
    // ═══════════════════════════════════════════════════════════

    public T? GetById(string id)
    {
        return _byId.TryGetValue(id, out var item) ? item : null;
    }

    public bool TryGetById(string id, out T? item)
    {
        return _byId.TryGetValue(id, out item);
    }

    public bool ContainsId(string id)
    {
        return _byId.ContainsKey(id);
    }

    // ═══════════════════════════════════════════════════════════
    //  Add Operations
    // ═══════════════════════════════════════════════════════════

    public void Add(T item)
    {
        ValidateItem(item);

        _items.Add(item);
        _byId[item.Id] = item;
        ConnectItem(item);

        _store?.NotifyAdded(_path!, item, item.Id);
    }

    public void AddRange(IEnumerable<T> items)
    {
        var itemList = items as IList<T> ?? items.ToList();
        
        if (itemList.Count == 0)
            return;

        // Validate all first
        foreach (var item in itemList)
        {
            ValidateItem(item);
        }

        // Add all
        foreach (var item in itemList)
        {
            _items.Add(item);
            _byId[item.Id] = item;
            ConnectItem(item);
        }

        // Notify for each item
        if (_store != null)
        {
            foreach (var item in itemList)
            {
                _store.NotifyAdded(_path!, item, item.Id);
            }
        }
    }

    private void ValidateItem(T item)
    {
        if (item == null)
            throw new ArgumentNullException(nameof(item));

        if (_byId.ContainsKey(item.Id))
            throw new ArgumentException($"Item with ID '{item.Id}' already exists.");
    }

    // ═══════════════════════════════════════════════════════════
    //  Remove Operations
    // ═══════════════════════════════════════════════════════════

    public bool Remove(string id)
    {
        if (!_byId.TryGetValue(id, out var item))
            return false;

        DisconnectItem(item);
        _items.Remove(item);
        _byId.Remove(id);

        _store?.NotifyRemoved(_path!, item, id);
        return true;
    }

    public int RemoveWhere(Func<T, bool> predicate)
    {
        var toRemove = _items.Where(predicate).ToList();
        
        if (toRemove.Count == 0)
            return 0;

        foreach (var item in toRemove)
        {
            DisconnectItem(item);
            _items.Remove(item);
            _byId.Remove(item.Id);
            
            _store?.NotifyRemoved(_path!, item, item.Id);
        }

        return toRemove.Count;
    }

    public void Clear()
    {
        if (_items.Count == 0)
            return;

        var previousCount = _items.Count;

        foreach (var item in _items)
        {
            DisconnectItem(item);
        }

        _items.Clear();
        _byId.Clear();

        _store?.NotifyCleared(_path!, previousCount);
    }

    // ═══════════════════════════════════════════════════════════
    //  Replace
    // ═══════════════════════════════════════════════════════════

    public void ReplaceAll(IEnumerable<T> newItems)
    {
        var newList = newItems as IList<T> ?? newItems.ToList();

        // Validate all new items first
        var newIds = new HashSet<string>(StringComparer.Ordinal);
        foreach (var item in newList)
        {
            if (item == null)
                throw new ArgumentNullException(nameof(newItems), "Contains null.");
            
            if (!newIds.Add(item.Id))
                throw new ArgumentException($"Duplicate ID '{item.Id}'.");
        }

        // Disconnect old
        foreach (var item in _items)
        {
            DisconnectItem(item);
        }

        var oldCount = _items.Count;

        // Clear
        _items.Clear();
        _byId.Clear();

        // Add new
        foreach (var item in newList)
        {
            _items.Add(item);
            _byId[item.Id] = item;
            ConnectItem(item);
        }

        // Notify as clear + adds
        if (_store != null)
        {
            _store.NotifyCleared(_path!, oldCount);
            foreach (var item in newList)
            {
                _store.NotifyAdded(_path!, item, item.Id);
            }
        }
    }
}