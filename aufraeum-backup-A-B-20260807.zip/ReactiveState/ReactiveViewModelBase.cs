using System.ComponentModel;
using ReactiveState;

public abstract class ReactiveViewModelBase : IReactiveViewModel
{
    private readonly List<IDisposable> _subscriptions = new();
    private IStateStore? _store;

    public bool IsAttached => _store != null;
    public IStateStore? Store => _store;

    public event PropertyChangedEventHandler? PropertyChanged;

    public void Attach(IStateStore store)
    {
        if (_store != null)
            throw new InvalidOperationException("Already attached. Call Detach() first.");

        _store = store ?? throw new ArgumentNullException(nameof(store));
        OnAttach(store);
    }

    public void Detach()
    {
        if (_store == null)
            return;

        OnDetach();

        foreach (var sub in _subscriptions)
        {
            sub.Dispose();
        }

        _subscriptions.Clear();

        _store = null;
    }

    /// <summary>
    /// Override to set up subscriptions.
    /// </summary>
    protected abstract void OnAttach(IStateStore store);

    /// <summary>
    /// Override for custom cleanup logic.
    /// </summary>
    protected virtual void OnDetach()
    {
    }

    /// <summary>
    /// Adds a subscription that will be disposed on Detach.
    /// </summary>
    protected void AddSubscription(IDisposable subscription)
    {
        _subscriptions.Add(subscription);
    }

    /// <summary>
    /// Subscribes to a path and automatically manages disposal.
    /// </summary>
    protected void Subscribe(string path, Action<Change> handler)
    {
        if (_store == null)
            throw new InvalidOperationException("Not attached.");

        _subscriptions.Add(_store.Subscribe(path, handler));
    }

    /// <summary>
    /// Raises PropertyChanged event.
    /// </summary>
    protected void RaisePropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}