namespace ReactiveState;

/// <summary>
/// Represents a single change in the state.
/// </summary>
public readonly record struct Change
{
    /// <summary>
    /// The path of the changed property (e.g. "UserName", "Todos[id:abc].Title").
    /// </summary>
    public required string Path { get; init; }

    /// <summary>
    /// The kind of change.
    /// </summary>
    public required ChangeKind Kind { get; init; }

    /// <summary>
    /// The value before the change. Null for Add operations.
    /// </summary>
    public object? OldValue { get; init; }

    /// <summary>
    /// The value after the change. Null for Remove operations.
    /// </summary>
    public object? NewValue { get; init; }

    // ═══════════════════════════════════════════════════════════
    //  Factories
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Creates a Set change.
    /// </summary>
    public static Change Set(string path, object? oldValue, object? newValue) => new()
    {
        Path = path,
        Kind = ChangeKind.Set,
        OldValue = oldValue,
        NewValue = newValue
    };

    /// <summary>
    /// Creates an Add change.
    /// </summary>
    public static Change Add(string path, object? item) => new()
    {
        Path = path,
        Kind = ChangeKind.Add,
        OldValue = null,
        NewValue = item
    };

    /// <summary>
    /// Creates a Remove change.
    /// </summary>
    public static Change Remove(string path, object? item) => new()
    {
        Path = path,
        Kind = ChangeKind.Remove,
        OldValue = item,
        NewValue = null
    };

    /// <summary>
    /// Creates a Replace change.
    /// </summary>
    public static Change Replace(string path, object? oldItem, object? newItem) => new()
    {
        Path = path,
        Kind = ChangeKind.Replace,
        OldValue = oldItem,
        NewValue = newItem
    };

    /// <summary>
    /// Creates a Clear change.
    /// </summary>
    public static Change Clear(string path, int previousCount) => new()
    {
        Path = path,
        Kind = ChangeKind.Clear,
        OldValue = previousCount,
        NewValue = 0
    };

    /// <summary>
    /// Creates a Computed change.
    /// </summary>
    public static Change Computed(string path, object? oldValue, object? newValue) => new()
    {
        Path = path,
        Kind = ChangeKind.Computed,
        OldValue = oldValue,
        NewValue = newValue
    };

    // ═══════════════════════════════════════════════════════════
    //  Helpers
    // ═══════════════════════════════════════════════════════════

    /// <summary>
    /// Returns true if this change affects the given path or a child of it.
    /// </summary>
    public bool Affects(string pathPrefix)
    {
        return Path.Equals(pathPrefix, StringComparison.Ordinal)
            || Path.StartsWith(pathPrefix + ".", StringComparison.Ordinal)
            || Path.StartsWith(pathPrefix + "[", StringComparison.Ordinal);
    }

    /// <summary>
    /// Returns true if this change is for a collection item (contains [id:...]).
    /// </summary>
    public bool IsCollectionItem => Path.Contains("[id:");

    /// <summary>
    /// Extracts the collection path from an item path.
    /// "Todos[id:abc].Title" -> "Todos"
    /// </summary>
    public string? GetCollectionPath()
    {
        var bracketIndex = Path.IndexOf('[');
        return bracketIndex > 0 ? Path[..bracketIndex] : null;
    }

    /// <summary>
    /// Extracts the item ID from an item path.
    /// "Todos[id:abc].Title" -> "abc"
    /// </summary>
    public string? GetItemId()
    {
        var start = Path.IndexOf("[id:", StringComparison.Ordinal);
        if (start < 0) return null;

        start += 4; // Length of "[id:"
        var end = Path.IndexOf(']', start);
        return end > start ? Path[start..end] : null;
    }

    /// <summary>
    /// Extracts the property name after the item.
    /// "Todos[id:abc].Title" -> "Title"
    /// "Todos[id:abc]" -> null
    /// </summary>
    public string? GetItemProperty()
    {
        var bracketEnd = Path.IndexOf(']');
        if (bracketEnd < 0 || bracketEnd >= Path.Length - 1) return null;

        // Skip the "]."
        return Path[(bracketEnd + 2)..];
    }

    // ═══════════════════════════════════════════════════════════
    //  ToString
    // ═══════════════════════════════════════════════════════════

    public override string ToString() => Kind switch
    {
        ChangeKind.Set => $"Set({Path}: {OldValue} → {NewValue})",
        ChangeKind.Add => $"Add({Path}: {NewValue})",
        ChangeKind.Remove => $"Remove({Path}: {OldValue})",
        ChangeKind.Replace => $"Replace({Path}: {OldValue} → {NewValue})",
        ChangeKind.Clear => $"Clear({Path}: {OldValue} items)",
        ChangeKind.Computed => $"Computed({Path}: {OldValue} → {NewValue})",
        _ => $"Unknown({Path})"
    };
}




/// <summary>
/// A strongly-typed change for when you know the value type.
/// </summary>
public readonly record struct Change<T>
{
    public required string Path { get; init; }
    public required ChangeKind Kind { get; init; }
    public T? OldValue { get; init; }
    public T? NewValue { get; init; }

    /// <summary>
    /// Converts to untyped Change.
    /// </summary>
    public Change ToUntyped() => new()
    {
        Path = Path,
        Kind = Kind,
        OldValue = OldValue,
        NewValue = NewValue
    };

    /// <summary>
    /// Creates from untyped Change.
    /// </summary>
    public static Change<T> FromUntyped(Change change) => new()
    {
        Path = change.Path,
        Kind = change.Kind,
        OldValue = change.OldValue is T old ? old : default,
        NewValue = change.NewValue is T @new ? @new : default
    };

    public static Change<T> Set(string path, T? oldValue, T? newValue) => new()
    {
        Path = path,
        Kind = ChangeKind.Set,
        OldValue = oldValue,
        NewValue = newValue
    };
}