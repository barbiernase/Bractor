﻿using ReactiveState.Application.Demos;

namespace ReactiveState.Application;

public static class Program
{
    public static async Task Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        
        var demos = new (string Name, Func<Task> Run)[]
        {
            ("LazyValue<T>", LazyValueDemo.RunAsync),
            ("Change & ChangeKind", ChangeDemo.RunAsync),
            ("PropertyPath", PropertyPathDemo.RunAsync),
            ("GraphNode & GraphEdge", GraphNodeDemo.RunAsync),
            ("DependencyGraph", DependencyGraphDemo.RunAsync),
            ("ComputeQueue", ComputeQueueDemo.RunAsync),
            ("StateStore", StateStoreDemo.RunAsync),
            ("ComputeEngine", ComputeEngineDemo.RunAsync),
            ("TrackedList", TrackedListDemo.RunAsync),
        };

        Console.WriteLine("╔════════════════════════════════════════════════════════════╗");
        Console.WriteLine("║         ReactiveState - Component Demonstrations           ║");
        Console.WriteLine("╚════════════════════════════════════════════════════════════╝");
        Console.WriteLine();

        for (var i = 0; i < demos.Length; i++)
        {
            var (name, run) = demos[i];
            
            Console.WriteLine($"┌────────────────────────────────────────────────────────────┐");
            Console.WriteLine($"│ Demo {i + 1}/{demos.Length}: {name,-46} │");
            Console.WriteLine($"└────────────────────────────────────────────────────────────┘");
            Console.WriteLine();

            try
            {
                await run();
                Console.WriteLine();
                Console.WriteLine("  ✓ Demo completed successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine($"  ✗ Demo failed: {ex.Message}");
                Console.WriteLine($"    {ex.StackTrace}");
            }

            Console.WriteLine();
            
            
        }

        Console.WriteLine("╔════════════════════════════════════════════════════════════╗");
        Console.WriteLine("║                    All demos completed!                    ║");
        Console.WriteLine("╚════════════════════════════════════════════════════════════╝");
    }
}