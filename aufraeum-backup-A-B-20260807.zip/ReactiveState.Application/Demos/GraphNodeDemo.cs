using ReactiveState.Graph;

namespace ReactiveState.Application.Demos;

public static class GraphNodeDemo
{
    public static Task RunAsync()
    {
        // === Creating Nodes ===
        Section("Creating GraphNodes");
        
        var tracked = GraphNode.Tracked("UserName");
        var computed = GraphNode.Computed("FullName", level: 1);
        var asyncComputed = GraphNode.Computed("Report", level: 2, isAsync: true);
        var templateTracked = GraphNode.Tracked("Todos[*].Title");
        var templateComputed = GraphNode.Computed("Todos[*].DisplayTitle", level: 1);

        Print("Tracked", tracked);
        Print("Computed", computed);
        Print("Async Computed", asyncComputed);
        Print("Template Tracked", templateTracked);
        Print("Template Computed", templateComputed);

        // === Node Properties ===
        Section("Node Properties");
        
        Console.WriteLine($"  tracked.Path       = {tracked.Path}");
        Console.WriteLine($"  tracked.Kind       = {tracked.Kind}");
        Console.WriteLine($"  tracked.Level      = {tracked.Level}");
        Console.WriteLine($"  tracked.IsAsync    = {tracked.IsAsync}");
        Console.WriteLine($"  tracked.IsTracked  = {tracked.IsTracked}");
        Console.WriteLine($"  tracked.IsComputed = {tracked.IsComputed}");
        Console.WriteLine($"  tracked.IsTemplate = {tracked.IsTemplate}");
        Console.WriteLine();
        Console.WriteLine($"  asyncComputed.IsAsync = {asyncComputed.IsAsync}");
        Console.WriteLine($"  templateTracked.IsTemplate = {templateTracked.IsTemplate}");

        // === Template to Instance ===
        Section("Template → Instance Conversion");
        
        Console.WriteLine($"  Template: {templateTracked.Path}");
        Console.WriteLine($"  ToInstancePath(\"abc123\"):");
        Console.WriteLine($"    → {templateTracked.ToInstancePath("abc123")}");

        // === Creating Edges ===
        Section("Creating GraphEdges");
        
        var edge1 = GraphEdge.Create("Count", "Doubled");
        var edge2 = GraphEdge.DependsOn("FirstName", "FullName");
        var templateEdge = GraphEdge.Create("Todos[*].Title", "Todos[*].DisplayTitle");

        Console.WriteLine($"  {edge1}");
        Console.WriteLine($"  {edge2}");
        Console.WriteLine($"  {templateEdge}");
        Console.WriteLine();
        Console.WriteLine("  Note: Both Create() and DependsOn() create the same edge,");
        Console.WriteLine("        but DependsOn() reads more naturally.");

        // === Edge Properties ===
        Section("Edge Properties");
        
        Console.WriteLine($"  edge1.From       = {edge1.From}");
        Console.WriteLine($"  edge1.To         = {edge1.To}");
        Console.WriteLine($"  edge1.IsTemplate = {edge1.IsTemplate}");
        Console.WriteLine($"  templateEdge.IsTemplate = {templateEdge.IsTemplate}");

        // === Edge Instance Conversion ===
        Section("Edge Template → Instance");
        
        Console.WriteLine($"  Template Edge: {templateEdge}");
        Console.WriteLine($"  ToInstanceEdge(\"item-1\"):");
        Console.WriteLine($"    → {templateEdge.ToInstanceEdge("item-1")}");

        // === NodeKind Enum ===
        Section("NodeKind Values");
        
        foreach (NodeKind kind in Enum.GetValues<NodeKind>())
        {
            Console.WriteLine($"  {kind} = {(int)kind}");
        }

        // === Practical Example ===
        Section("Practical Example: Todo App Nodes");
        
        var todoNodes = new[]
        {
            GraphNode.Tracked("UserName"),
            GraphNode.Tracked("Todos"),
            GraphNode.Tracked("Todos[*].Id"),
            GraphNode.Tracked("Todos[*].Title"),
            GraphNode.Tracked("Todos[*].IsCompleted"),
            GraphNode.Computed("Todos[*].DisplayTitle", 1),
            GraphNode.Computed("TodoCount", 1),
            GraphNode.Computed("OpenCount", 1),
            GraphNode.Computed("AllDone", 2),
        };

        Console.WriteLine("  Path                      │ Kind     │ Level │ Template?");
        Console.WriteLine("  ──────────────────────────┼──────────┼───────┼──────────");
        
        foreach (var node in todoNodes)
        {
            Console.WriteLine(
                $"  {node.Path,-25} │ {node.Kind,-8} │ {node.Level,5} │ {node.IsTemplate}");
        }

        return Task.CompletedTask;
    }

    private static void Section(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"  ── {title} ──");
        Console.WriteLine();
    }

    private static void Print(string label, GraphNode node)
    {
        Console.WriteLine($"  {label,-18}: {node}");
    }
}