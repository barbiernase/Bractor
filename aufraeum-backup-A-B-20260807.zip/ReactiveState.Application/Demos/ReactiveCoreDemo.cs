using ReactiveState;
using ReactiveState.Graph;
using ReactiveState.Runtime;

namespace ReactiveState.Application.Demos;

public static class ReactiveCoreDemo
{
    public static async Task RunAsync()
    {
        // === Setup ===
        Section("Setting Up ReactiveCore");
        
        // Build graph
        var graph = new DependencyGraphBuilder()
            .AddTracked("Count")
            .AddComputed("Doubled", dependsOn: "Count")
            .AddComputed("Message", dependsOn: "Doubled")
            .Build();

        Console.WriteLine("  Graph:");
        Console.WriteLine("    Count (tracked, level 0)");
        Console.WriteLine("      └─► Doubled (computed, level 1)");
        Console.WriteLine("            └─► Message (computed, level 2)");
        Console.WriteLine();

        // State
        int count = 0;
        int doubled = 0;
        string message = "";

        using var core = new ReactiveCore(graph);

        // Register computers
        core.Register("Doubled", () =>
        {
            var newValue = count * 2;
            if (newValue != doubled)
            {
                var old = doubled;
                doubled = newValue;
                return ComputeResult.Changed(old, newValue);
            }
            return ComputeResult.Unchanged();
        });

        core.Register("Message", () =>
        {
            var newValue = $"Doubled value is {doubled}";
            if (newValue != message)
            {
                var old = message;
                message = newValue;
                return ComputeResult.Changed(old, newValue);
            }
            return ComputeResult.Unchanged();
        });

        Console.WriteLine("  Computers registered for 'Doubled' and 'Message'");

        // === Initial State ===
        Section("Initial State");
        
        Console.WriteLine($"  count   = {count}");
        Console.WriteLine($"  doubled = {doubled}");
        Console.WriteLine($"  message = \"{message}\"");
        Console.WriteLine();
        Console.WriteLine($"  IsDirty(\"Doubled\") = {core.IsDirty("Doubled")}");
        Console.WriteLine($"  IsDirty(\"Message\") = {core.IsDirty("Message")}");
        Console.WriteLine();
        Console.WriteLine("  Note: Computed properties start dirty");

        // === Mutation ===
        Section("Notifying a Change");
        
        Console.WriteLine("  Setting count = 5...");
        var oldCount = count;
        count = 5;
        core.NotifyChanged("Count", oldCount, count);

        Console.WriteLine();
        Console.WriteLine($"  Version: {core.Version}");
        Console.WriteLine($"  Changes so far: {core.Changes.Count}");
        foreach (var c in core.Changes)
        {
            Console.WriteLine($"    • {c}");
        }

        // === Synchronous Compute ===
        Section("Synchronous Computation");
        
        Console.WriteLine("  Calling ComputeAllSync()...");
        core.ComputeAllSync();

        Console.WriteLine();
        Console.WriteLine($"  After sync compute:");
        Console.WriteLine($"    count   = {count}");
        Console.WriteLine($"    doubled = {doubled}");
        Console.WriteLine($"    message = \"{message}\"");
        Console.WriteLine();
        Console.WriteLine($"  All changes:");
        foreach (var c in core.Changes)
        {
            Console.WriteLine($"    • {c}");
        }

        // === ConsumeChanges ===
        Section("Consuming Changes");
        
        Console.WriteLine($"  Changes before consume: {core.Changes.Count}");
        var consumed = core.ConsumeChanges();
        Console.WriteLine($"  Consumed: {consumed.Count} changes");
        Console.WriteLine($"  Changes after consume: {core.Changes.Count}");

        // === OnChanges Event ===
        Section("OnChanges Event");
        
        var eventFired = false;
        core.OnChanges += changes =>
        {
            eventFired = true;
            Console.WriteLine($"    📢 OnChanges: {changes.Count} change(s)");
        };

        Console.WriteLine("  Subscribed to OnChanges");
        Console.WriteLine("  Setting count = 10...");
        
        oldCount = count;
        count = 10;
        core.NotifyChanged("Count", oldCount, count);

        // Wait for worker
        await Task.Delay(100);

        Console.WriteLine();
        Console.WriteLine($"  Event fired: {eventFired}");
        Console.WriteLine($"  New values: doubled={doubled}, message=\"{message}\"");

        // === Multiple Rapid Changes ===
        Section("Multiple Rapid Changes");
        
        core.ConsumeChanges();
        
        Console.WriteLine("  Rapidly changing count 3 times...");
        
        for (int i = 20; i <= 22; i++)
        {
            oldCount = count;
            count = i;
            core.NotifyChanged("Count", oldCount, count);
            Console.WriteLine($"    Set count = {i}, version = {core.Version}");
        }

        await Task.Delay(100);

        Console.WriteLine();
        Console.WriteLine($"  Final: doubled={doubled}, message=\"{message}\"");
        Console.WriteLine($"  Changes logged: {core.Changes.Count}");

        // === Dirty Management ===
        Section("Dirty Flag Management");
        
        core.ConsumeChanges();
        
        Console.WriteLine($"  IsDirty(\"Doubled\"): {core.IsDirty("Doubled")}");
        Console.WriteLine($"  IsDirty(\"Message\"): {core.IsDirty("Message")}");
        Console.WriteLine();
        Console.WriteLine("  Manually marking 'Doubled' as dirty...");
        core.MarkDirty("Doubled");
        Console.WriteLine($"  IsDirty(\"Doubled\"): {core.IsDirty("Doubled")}");

        // === Graph Access ===
        Section("Accessing the Graph");
        
        Console.WriteLine($"  core.Graph.Nodes.Count = {core.Graph.Nodes.Count}");
        Console.WriteLine($"  core.Graph.MaxLevel = {core.Graph.MaxLevel}");
        Console.WriteLine();
        Console.WriteLine("  Nodes:");
        foreach (var node in core.Graph.Nodes)
        {
            Console.WriteLine($"    • {node}");
        }

        // === Practical Pattern ===
        Section("Practical Usage Pattern");
        
        Console.WriteLine(@"
    // 1. Define your state class
    class AppState
    {
        private readonly ReactiveCore _core;
        private int _count;
        private int _doubled;
        
        public int Count
        {
            get => _count;
            set
            {
                if (_count != value)
                {
                    var old = _count;
                    _count = value;
                    _core.NotifyChanged(""Count"", old, value);
                }
            }
        }
        
        public int Doubled => _doubled;
    }
    
    // 2. React to changes
    state.OnChanges += changes =>
    {
        foreach (var c in changes.Where(c => c.Kind == ChangeKind.Computed))
        {
            UpdateUI(c.Path);
        }
    };
    
    // 3. Mutate and let it flow
    state.Count = 42;  // Automatically triggers Doubled computation");

        return;
    }

    private static void Section(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"  ── {title} ──");
        Console.WriteLine();
    }
}