using ReactiveState;

namespace ReactiveState.Application.Demos;

public static class ChangeDemo
{
    public static Task RunAsync()
    {
        // === Change erstellen ===
        Section("Creating Changes");
        
        var setChange = Change.Set("UserName", "Max", "Anna");
        var addChange = Change.Add("Todos", new { Id = "1", Title = "Buy milk" });
        var removeChange = Change.Remove("Todos", new { Id = "1", Title = "Buy milk" });
        var replaceChange = Change.Replace("Todos[0]", "old", "new");
        var clearChange = Change.Clear("Todos", 5);
        var computedChange = Change.Computed("TodoCount", 5, 6);

        Print(setChange);
        Print(addChange);
        Print(removeChange);
        Print(replaceChange);
        Print(clearChange);
        Print(computedChange);

        // === Change Properties ===
        Section("Change Properties");
        
        Console.WriteLine($"  setChange.Path     = {setChange.Path}");
        Console.WriteLine($"  setChange.Kind     = {setChange.Kind}");
        Console.WriteLine($"  setChange.OldValue = {setChange.OldValue}");
        Console.WriteLine($"  setChange.NewValue = {setChange.NewValue}");

        // === Collection Item Changes ===
        Section("Collection Item Paths");
        
        var itemChange = Change.Set("Todos[id:abc123].Title", "Old Title", "New Title");
        Print(itemChange);
        
        Console.WriteLine();
        Console.WriteLine($"  IsCollectionItem    = {itemChange.IsCollectionItem}");
        Console.WriteLine($"  GetCollectionPath() = {itemChange.GetCollectionPath()}");
        Console.WriteLine($"  GetItemId()         = {itemChange.GetItemId()}");
        Console.WriteLine($"  GetItemProperty()   = {itemChange.GetItemProperty()}");

        // === Affects Check ===
        Section("Affects() - Checking Impact");
        
        var changes = new[]
        {
            Change.Set("UserName", "a", "b"),
            Change.Set("Address.City", "Munich", "Berlin"),
            Change.Set("Address.Street", "Main St", "Oak Ave"),
            Change.Set("Todos[id:1].Title", "old", "new"),
            Change.Set("Todos[id:2].IsCompleted", false, true),
        };

        Console.WriteLine("  Changes:");
        foreach (var c in changes)
        {
            Console.WriteLine($"    • {c.Path}");
        }
        Console.WriteLine();

        var pathsToCheck = new[] { "UserName", "Address", "Todos", "Todos[id:1]", "Other" };
        foreach (var path in pathsToCheck)
        {
            var affected = changes.Count(c => c.Affects(path));
            Console.WriteLine($"  Affects(\"{path}\"): {affected} change(s)");
        }

        // === Extension Methods ===
        Section("Extension Methods");

        var mixedChanges = new[]
        {
            Change.Set("Count", 0, 1),
            Change.Add("Items", "item1"),
            Change.Add("Items", "item2"),
            Change.Remove("Items", "item0"),
            Change.Computed("Total", 0, 100),
        };

        Console.WriteLine("  All changes:");
        foreach (var c in mixedChanges)
        {
            Console.WriteLine($"    • {c}");
        }
        Console.WriteLine();

        Console.WriteLine($"  OfKind(Add):     {mixedChanges.OfKind(ChangeKind.Add).Count()} changes");
        Console.WriteLine($"  OfKind(Set):     {mixedChanges.OfKind(ChangeKind.Set).Count()} changes");
        Console.WriteLine($"  OfKind(Computed):{mixedChanges.OfKind(ChangeKind.Computed).Count()} changes");
        Console.WriteLine();

        Console.WriteLine($"  Affecting(\"Items\"):");
        foreach (var c in mixedChanges.Affecting("Items"))
        {
            Console.WriteLine($"    • {c}");
        }
        Console.WriteLine();

        Console.WriteLine($"  GetAffectedPaths(): [{string.Join(", ", mixedChanges.GetAffectedPaths())}]");
        Console.WriteLine($"  HasChangesFor(\"Count\"): {mixedChanges.HasChangesFor("Count")}");
        Console.WriteLine($"  HasChangesFor(\"Other\"): {mixedChanges.HasChangesFor("Other")}");

        // === ChangeKind Enum ===
        Section("ChangeKind Values");
        
        foreach (ChangeKind kind in Enum.GetValues<ChangeKind>())
        {
            Console.WriteLine($"  {kind} = {(int)kind}");
        }

        return Task.CompletedTask;
    }

    private static void Section(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"  ── {title} ──");
        Console.WriteLine();
    }

    private static void Print(Change change)
    {
        Console.WriteLine($"  {change}");
    }
}