using ReactiveState.Runtime;

namespace ReactiveState.Application.Demos;

public static class ComputeWorkerDemo
{
    public static async Task RunAsync()
    {
        // === Setup ===
        Section("Setting Up ComputeWorker");
        
        var queue = new ComputeQueue();
        var computedValues = new Dictionary<string, int>();
        var changesReceived = new List<Change>();

        // Compute function
        async Task<ComputeResult> ComputeAsync(string path)
        {
            Console.WriteLine($"    ⚙️  Computing '{path}'...");
            await Task.Delay(50); // Simulate work
            
            var oldValue = computedValues.GetValueOrDefault(path, 0);
            var newValue = path switch
            {
                "Doubled" => 10 * 2,
                "Tripled" => 10 * 3,
                "Slow" => 999,
                _ => 0
            };
            
            computedValues[path] = newValue;
            
            if (oldValue != newValue)
            {
                Console.WriteLine($"    ✓  '{path}' computed: {oldValue} → {newValue}");
                return ComputeResult.Changed(oldValue, newValue);
            }
            
            Console.WriteLine($"    ○  '{path}' unchanged");
            return ComputeResult.Unchanged();
        }

        // Changes callback
        void OnChanges(IReadOnlyList<Change> changes)
        {
            changesReceived.AddRange(changes);
            Console.WriteLine($"    📢 OnChanges fired with {changes.Count} change(s)");
        }

        Console.WriteLine("  Creating worker...");
        using var worker = new ComputeWorker(queue, ComputeAsync, OnChanges);
        Console.WriteLine("  Worker created and running");

        // === Enqueue and Process ===
        Section("Enqueueing Computations");
        
        Console.WriteLine("  Enqueueing 'Doubled' (level 1) and 'Tripled' (level 1)...");
        queue.Enqueue("Doubled", 1);
        queue.Enqueue("Tripled", 1);
        
        Console.WriteLine("  Signaling worker...");
        worker.Signal();

        // Wait for processing
        await Task.Delay(200);

        Console.WriteLine();
        Console.WriteLine($"  Changes received: {changesReceived.Count}");
        foreach (var change in changesReceived)
        {
            Console.WriteLine($"    • {change}");
        }

        // === Level-Based Ordering ===
        Section("Level-Based Processing Order");
        
        changesReceived.Clear();
        
        Console.WriteLine("  Enqueueing: Slow(3), Doubled(1), Tripled(2)");
        Console.WriteLine("  Should process in order: Doubled → Tripled → Slow");
        Console.WriteLine();
        
        queue.Enqueue("Slow", 3);
        queue.Enqueue("Doubled", 1);
        queue.Enqueue("Tripled", 2);
        
        worker.Signal();
        await Task.Delay(300);

        // === ComputeResult ===
        Section("ComputeResult Type");
        
        Console.WriteLine("  ComputeResult can be:");
        Console.WriteLine();
        
        var unchanged = ComputeResult.Unchanged();
        var changed = ComputeResult.Changed(oldValue: 5, newValue: 10);
        
        Console.WriteLine($"    Unchanged: HasChanged={unchanged.HasChanged}");
        Console.WriteLine($"    Changed:   HasChanged={changed.HasChanged}, Old={changed.OldValue}, New={changed.NewValue}");

        // === Error Handling ===
        Section("Error Handling");
        
        var errorQueue = new ComputeQueue();
        var errorChanges = new List<Change>();

        async Task<ComputeResult> FailingCompute(string path)
        {
            if (path == "WillFail")
            {
                throw new InvalidOperationException("Simulated failure!");
            }
            return ComputeResult.Changed(0, 1);
        }

        using var errorWorker = new ComputeWorker(
            errorQueue,
            FailingCompute,
            changes => errorChanges.AddRange(changes));

        Console.WriteLine("  Enqueueing 'WillFail'...");
        errorQueue.Enqueue("WillFail", 1);
        errorWorker.Signal();
        
        await Task.Delay(100);

        Console.WriteLine();
        Console.WriteLine($"  Error changes received: {errorChanges.Count}");
        if (errorChanges.Count > 0)
        {
            var errorChange = errorChanges[0];
            Console.WriteLine($"    Path: {errorChange.Path}");
            Console.WriteLine($"    NewValue is Exception: {errorChange.NewValue is Exception}");
            if (errorChange.NewValue is Exception ex)
            {
                Console.WriteLine($"    Exception: {ex.Message}");
            }
        }
        Console.WriteLine();
        Console.WriteLine("  Worker continues running despite errors!");

        // === Cleanup ===
        Section("Cleanup");
        
        Console.WriteLine("  Disposing workers...");
        // Dispose happens via using

        return;
    }

    private static void Section(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"  ── {title} ──");
        Console.WriteLine();
    }
}