using ReactiveState;
using ReactiveState.Graph;

namespace ReactiveState.Application.Demos;

public static class StateStoreDemo
{
    public static async Task RunAsync()
    {
        // === Setup ===
        Section("Setting Up StateStore");
        
        // Build graph
        var graph = new DependencyGraphBuilder()
            .AddTracked("Count")
            .AddComputed("Doubled", dependsOn: "Count")
            .AddComputed("Message", dependsOn: "Doubled")
            .Build();

        Console.WriteLine("  Graph:");
        Console.WriteLine("    Count (tracked, level 0)");
        Console.WriteLine("      └─► Doubled (computed, level 1)");
        Console.WriteLine("            └─► Message (computed, level 2)");
        Console.WriteLine();

        // Create state
        var state = new DemoState();
        
        // Create store with options
        var options = new StateStoreOptions
        {
            UseDebouncing = false,  // For demo: immediate computation
            OnlyComputeSubscribed = true
        };
        
        using var store = new StateStore<DemoState>(state, graph, options);
        
        // Connect state to store
        state.Connect(store);

        Console.WriteLine("  State and Store created");

        // === Register Computed Properties ===
        Section("Register Computed Properties");
        
        store.RegisterComputed("Doubled", () => state.Count * 2);
        store.RegisterComputed("Message", () => $"Doubled value is {store.GetComputed<int>("Doubled").ValueOrDefault}");
        
        Console.WriteLine("  Registered: Doubled, Message");

        // === Initial State (No Subscribers) ===
        Section("Initial State (No Subscribers)");
        
        Console.WriteLine($"  state.Count = {state.Count}");
        Console.WriteLine($"  store.GetComputed<int>(\"Doubled\") = {store.GetComputed<int>("Doubled")}");
        Console.WriteLine($"  store.IsDirty(\"Doubled\") = {store.IsDirty("Doubled")}");
        Console.WriteLine();
        Console.WriteLine("  Note: Computed values are Pending because no one subscribed yet!");

        // === Subscribe ===
        Section("Subscribing");
        
        var changesReceived = new List<Change>();
        
        var sub1 = store.Subscribe("Doubled", change =>
        {
            changesReceived.Add(change);
            Console.WriteLine($"    📢 Doubled changed: {change.OldValue} → {change.NewValue}");
        });
        
        var sub2 = store.Subscribe("Message", change =>
        {
            changesReceived.Add(change);
            Console.WriteLine($"    📢 Message changed: {change.OldValue} → {change.NewValue}");
        });
        
        Console.WriteLine("  Subscribed to: Doubled, Message");
        Console.WriteLine($"  HasSubscribers(\"Doubled\") = {store.HasSubscribers("Doubled")}");

        // Wait for initial computation (triggered by subscription)
        await Task.Delay(50);
        
        Console.WriteLine();
        Console.WriteLine($"  After subscription + computation:");
        Console.WriteLine($"    GetComputed<int>(\"Doubled\") = {store.GetComputed<int>("Doubled")}");
        Console.WriteLine($"    GetComputed<string>(\"Message\") = {store.GetComputed<string>("Message")}");

        // === Mutation ===
        Section("Mutation");
        
        Console.WriteLine("  Setting state.Count = 5...");
        state.Count = 5;
        
        // Wait for computation
        await Task.Delay(50);
        
        Console.WriteLine();
        Console.WriteLine($"  After mutation:");
        Console.WriteLine($"    Version = {store.Version}");
        Console.WriteLine($"    GetComputed<int>(\"Doubled\") = {store.GetComputed<int>("Doubled")}");
        Console.WriteLine($"    GetComputed<string>(\"Message\") = {store.GetComputed<string>("Message")}");

        // === FlushSync ===
        Section("FlushSync (Synchronous)");
        
        Console.WriteLine("  Setting state.Count = 10...");
        state.Count = 10;
        
        Console.WriteLine("  Calling FlushSync()...");
        var changes = store.FlushSync();
        
        Console.WriteLine($"  FlushSync returned {changes.Count} changes");
        Console.WriteLine($"    GetComputed<int>(\"Doubled\") = {store.GetComputed<int>("Doubled")}");

        // === Consume Changes ===
        Section("Change Management");
        
        Console.WriteLine($"  store.HasChanges = {store.HasChanges}");
        Console.WriteLine($"  store.GetChanges().Count = {store.GetChanges().Count}");
        
        var consumed = store.ConsumeChanges();
        Console.WriteLine($"  ConsumeChanges() returned {consumed.Count} changes");
        Console.WriteLine($"  store.HasChanges = {store.HasChanges}");

        // === Unsubscribe ===
        Section("Unsubscribe");
        
        Console.WriteLine("  Disposing subscription to 'Doubled'...");
        sub1.Dispose();
        
        Console.WriteLine($"  HasSubscribers(\"Doubled\") = {store.HasSubscribers("Doubled")}");
        
        Console.WriteLine();
        Console.WriteLine("  Setting state.Count = 20...");
        state.Count = 20;
        await Task.Delay(50);
        
        Console.WriteLine("  (No notification for Doubled because no subscriber)");

        // === Cleanup ===
        Section("Cleanup");
        
        sub2.Dispose();
        Console.WriteLine("  All subscriptions disposed");
        Console.WriteLine("  Demo complete!");
    }

    private static void Section(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"  ── {title} ──");
        Console.WriteLine();
    }
}

/// <summary>
/// Demo state class (would be generated in real usage).
/// </summary>
public class DemoState
{
    private IStateStore? _store;
    private int _count;

    public int Count
    {
        get => _count;
        set
        {
            if (_count != value)
            {
                var old = _count;
                _count = value;
                _store?.NotifyChanged("Count", old, value);
            }
        }
    }

    public void Connect(IStateStore store)
    {
        _store = store;
    }
}