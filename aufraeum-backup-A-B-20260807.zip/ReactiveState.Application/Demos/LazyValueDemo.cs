using ReactiveState;

namespace ReactiveState.Application.Demos;

public static class LazyValueDemo
{
    public static Task RunAsync()
    {
        // === Erstellen der drei Zustände ===
        Section("Creating LazyValues");
        
        var pending = LazyValue<int>.Pending;
        var ready = LazyValue<int>.Ready(42);
        var failed = LazyValue<int>.Failed(new InvalidOperationException("Something went wrong"));

        Print("Pending", pending);
        Print("Ready", ready);
        Print("Failed", failed);

        // === Zustands-Checks ===
        Section("State Checks");
        
        Console.WriteLine($"  pending.IsPending = {pending.IsPending}");
        Console.WriteLine($"  pending.IsReady   = {pending.IsReady}");
        Console.WriteLine($"  pending.IsFailed  = {pending.IsFailed}");
        Console.WriteLine();
        Console.WriteLine($"  ready.IsPending   = {ready.IsPending}");
        Console.WriteLine($"  ready.IsReady     = {ready.IsReady}");
        Console.WriteLine($"  ready.Value       = {ready.Value}");

        // === Value-Zugriff ===
        Section("Value Access");
        
        Console.WriteLine($"  ready.Value          = {ready.Value}");
        Console.WriteLine($"  ready.ValueOrDefault = {ready.ValueOrDefault}");
        Console.WriteLine($"  pending.ValueOrDefault = {pending.ValueOrDefault}");
        
        if (ready.TryGetValue(out var value))
        {
            Console.WriteLine($"  TryGetValue succeeded: {value}");
        }

        // === Pattern Matching ===
        Section("Pattern Matching with Match()");
        
        string Display(LazyValue<int> lv) => lv.Match(
            pending: () => "⏳ Loading...",
            ready: v => $"✓ Value: {v}",
            failed: ex => $"✗ Error: {ex.Message}"
        );

        Console.WriteLine($"  pending → {Display(pending)}");
        Console.WriteLine($"  ready   → {Display(ready)}");
        Console.WriteLine($"  failed  → {Display(failed)}");

        // === Transformationen ===
        Section("Transformations with Select()");
        
        var doubled = ready.Select(x => x * 2);
        var pendingDoubled = pending.Select(x => x * 2);
        var failedDoubled = failed.Select(x => x * 2);

        Console.WriteLine($"  ready.Select(x => x * 2)   → {doubled}");
        Console.WriteLine($"  pending.Select(x => x * 2) → {pendingDoubled}");
        Console.WriteLine($"  failed.Select(x => x * 2)  → {failedDoubled}");

        // === SelectMany (Flat Map) ===
        Section("Flat Map with SelectMany()");
        
        LazyValue<int> SafeDivide(int x) => x == 0 
            ? LazyValue<int>.Failed(new DivideByZeroException()) 
            : LazyValue<int>.Ready(100 / x);

        var divided = ready.SelectMany(SafeDivide);
        Console.WriteLine($"  Ready(42).SelectMany(SafeDivide) → {divided}");

        var zero = LazyValue<int>.Ready(0);
        var dividedByZero = zero.SelectMany(SafeDivide);
        Console.WriteLine($"  Ready(0).SelectMany(SafeDivide)  → {dividedByZero}");

        // === Fallbacks ===
        Section("Fallbacks with GetValueOr()");
        
        Console.WriteLine($"  ready.GetValueOr(0)   = {ready.GetValueOr(0)}");
        Console.WriteLine($"  pending.GetValueOr(0) = {pending.GetValueOr(0)}");
        Console.WriteLine($"  failed.GetValueOr(0)  = {failed.GetValueOr(0)}");
        Console.WriteLine($"  pending.GetValueOr(() => -1) = {pending.GetValueOr(() => -1)}");

        // === Kombinieren ===
        Section("Combining LazyValues");
        
        var a = LazyValue<int>.Ready(10);
        var b = LazyValue<int>.Ready(20);
        var c = LazyValue<int>.Pending;

        var combined = LazyValue.Combine(a, b);
        Console.WriteLine($"  Combine(Ready(10), Ready(20)) → {combined}");

        var combinedWithPending = LazyValue.Combine(a, c);
        Console.WriteLine($"  Combine(Ready(10), Pending)   → {combinedWithPending}");

        var list = new[] { a, b };
        var all = LazyValue.All(list);
        Console.WriteLine($"  All([Ready(10), Ready(20)])   → {all}");

        // === Equality ===
        Section("Equality");
        
        var ready1 = LazyValue<int>.Ready(42);
        var ready2 = LazyValue<int>.Ready(42);
        var ready3 = LazyValue<int>.Ready(99);

        Console.WriteLine($"  Ready(42) == Ready(42) → {ready1 == ready2}");
        Console.WriteLine($"  Ready(42) == Ready(99) → {ready1 == ready3}");
        Console.WriteLine($"  Pending == Pending     → {LazyValue<int>.Pending == LazyValue<int>.Pending}");

        return Task.CompletedTask;
    }

    private static void Section(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"  ── {title} ──");
        Console.WriteLine();
    }

    private static void Print<T>(string name, LazyValue<T> value)
    {
        Console.WriteLine($"  {name,-10} = {value}");
    }
}