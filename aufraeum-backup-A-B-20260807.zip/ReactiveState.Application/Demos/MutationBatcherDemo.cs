using ReactiveState.Runtime;

namespace ReactiveState.Application.Demos;

public static class MutationBatcherDemo
{
    public static async Task RunAsync()
    {
        // === Basic Batching ===
        Section("Basic Mutation Batching");
        
        Console.WriteLine("  Creating batcher with 50ms debounce...");
        
        using var batcher = new MutationBatcher(TimeSpan.FromMilliseconds(50));
        var batchesReceived = new List<int>();

        // Start consumer
        var consumerTask = Task.Run(async () =>
        {
            await foreach (var batch in batcher.Batches.ReadAllAsync())
            {
                batchesReceived.Add(batch.Count);
                Console.WriteLine($"    📦 Received batch with {batch.Count} mutation(s)");
            }
        });

        // Queue mutations rapidly
        Console.WriteLine();
        Console.WriteLine("  Queueing 5 mutations rapidly...");
        
        for (int i = 0; i < 5; i++)
        {
            var index = i;
            batcher.QueueMutation(() => Console.WriteLine($"      Mutation {index} executed"));
            await Task.Delay(10); // 10ms between mutations
        }

        // Wait for batch to be emitted
        await Task.Delay(100);

        Console.WriteLine();
        Console.WriteLine($"  Batches received: {batchesReceived.Count}");
        Console.WriteLine("  All 5 mutations should be in 1 batch (queued within 50ms window)");

        // === Separate Batches ===
        Section("Separate Batches");
        
        batchesReceived.Clear();
        
        Console.WriteLine("  Queueing mutation, waiting 100ms, queueing another...");
        
        batcher.QueueMutation(() => { });
        await Task.Delay(100); // Wait longer than debounce
        
        batcher.QueueMutation(() => { });
        await Task.Delay(100);

        Console.WriteLine($"  Batches received: {batchesReceived.Count}");
        Console.WriteLine("  Should be 2 separate batches");

        // === Debounce Behavior ===
        Section("Debounce Behavior Explained");
        
        Console.WriteLine("  The MutationBatcher works like this:");
        Console.WriteLine();
        Console.WriteLine("  1. Mutation comes in → start collecting");
        Console.WriteLine("  2. Wait [debounceTime] for more mutations");
        Console.WriteLine("  3. Collect any that arrive during wait");
        Console.WriteLine("  4. Emit batch with all collected mutations");
        Console.WriteLine("  5. Go back to waiting for next mutation");
        Console.WriteLine();
        Console.WriteLine("  This prevents rapid mutations from causing");
        Console.WriteLine("  excessive recomputations (e.g., typing in a search box)");

        // === Cleanup ===
        Section("Cleanup");
        
        Console.WriteLine("  Disposing batcher...");
        batcher.Dispose();
        
        // Wait for consumer to finish
        await consumerTask;
        
        Console.WriteLine("  Consumer task completed");

        // === Usage Pattern ===
        Section("Typical Usage Pattern");
        
        Console.WriteLine(@"
    // In ReactiveCore:
    
    var batcher = new MutationBatcher(TimeSpan.FromMilliseconds(16));
    
    // When state changes:
    batcher.QueueMutation(() => {
        _state.SomeProperty = newValue;
        MarkAffectedDirty(""SomeProperty"");
    });
    
    // Consumer processes batches:
    await foreach (var batch in batcher.Batches.ReadAllAsync())
    {
        // Execute all mutations
        foreach (var mutation in batch)
            mutation();
        
        // Then recompute affected properties (once!)
        ProcessComputeQueue();
    }");

        return;
    }

    private static void Section(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"  ── {title} ──");
        Console.WriteLine();
    }
}