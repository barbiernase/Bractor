using ReactiveState.Runtime;

namespace ReactiveState.Application.Demos;

public static class ComputeQueueDemo
{
    public static Task RunAsync()
    {
        // === Basic Usage ===
        Section("Basic Queue Operations");
        
        var queue = new ComputeQueue();

        Console.WriteLine($"  Initial state: IsEmpty = {queue.IsEmpty}, Count = {queue.Count}");
        Console.WriteLine();

        // Enqueue items with different levels
        Console.WriteLine("  Enqueueing items:");
        Console.WriteLine("    Enqueue(\"Level2Prop\", level: 2)");
        Console.WriteLine("    Enqueue(\"Level1PropA\", level: 1)");
        Console.WriteLine("    Enqueue(\"Level3Prop\", level: 3)");
        Console.WriteLine("    Enqueue(\"Level1PropB\", level: 1)");

        queue.Enqueue("Level2Prop", 2);
        queue.Enqueue("Level1PropA", 1);
        queue.Enqueue("Level3Prop", 3);
        queue.Enqueue("Level1PropB", 1);

        Console.WriteLine();
        Console.WriteLine($"  After enqueueing: Count = {queue.Count}");

        // === Priority Order ===
        Section("Dequeue Order (by Level)");
        
        Console.WriteLine("  Dequeuing all items:");
        while (queue.TryDequeue(out var path, out var level))
        {
            Console.WriteLine($"    Level {level}: {path}");
        }
        Console.WriteLine();
        Console.WriteLine("  Note: Items come out sorted by level (lowest first)");

        // === Duplicate Prevention ===
        Section("Duplicate Prevention");
        
        queue.Enqueue("PropA", 1);
        var firstEnqueue = queue.Enqueue("PropB", 1);
        var duplicateEnqueue = queue.Enqueue("PropA", 1); // Already in queue

        Console.WriteLine($"  Enqueue(\"PropA\", 1) → {firstEnqueue} (first time)");
        Console.WriteLine($"  Enqueue(\"PropB\", 1) → true");
        Console.WriteLine($"  Enqueue(\"PropA\", 1) → {duplicateEnqueue} (duplicate)");
        Console.WriteLine();
        Console.WriteLine($"  Queue count: {queue.Count} (not 3!)");

        // Clear for next section
        queue.Clear();

        // === Contains Check ===
        Section("Contains Check");
        
        queue.Enqueue("TestProp", 1);
        
        Console.WriteLine($"  Contains(\"TestProp\") = {queue.Contains("TestProp")}");
        Console.WriteLine($"  Contains(\"Other\")    = {queue.Contains("Other")}");
        
        queue.TryDequeue(out _, out _);
        Console.WriteLine();
        Console.WriteLine("  After dequeue:");
        Console.WriteLine($"  Contains(\"TestProp\") = {queue.Contains("TestProp")}");

        // === EnqueueRange ===
        Section("EnqueueRange");
        
        queue.Clear();
        
        var items = new[]
        {
            ("Prop1", 1),
            ("Prop2", 2),
            ("Prop3", 1),
            ("Prop1", 1), // Duplicate
        };

        var enqueued = queue.EnqueueRange(items);
        Console.WriteLine($"  EnqueueRange with 4 items (1 duplicate)");
        Console.WriteLine($"  Actually enqueued: {enqueued}");
        Console.WriteLine($"  Queue count: {queue.Count}");

        // === DequeueAll ===
        Section("DequeueAll");
        
        queue.Clear();
        queue.Enqueue("C", 3);
        queue.Enqueue("A", 1);
        queue.Enqueue("B", 2);

        Console.WriteLine("  Queue contains: C(3), A(1), B(2)");
        Console.WriteLine();

        var all = queue.DequeueAll();
        Console.WriteLine("  DequeueAll() returns:");
        foreach (var (path, level) in all)
        {
            Console.WriteLine($"    ({path}, {level})");
        }
        Console.WriteLine();
        Console.WriteLine($"  Queue after DequeueAll: IsEmpty = {queue.IsEmpty}");

        // === Thread Safety Note ===
        Section("Thread Safety");
        
        Console.WriteLine("  ComputeQueue is thread-safe:");
        Console.WriteLine("    • All operations are protected by a lock");
        Console.WriteLine("    • Safe to Enqueue from multiple threads");
        Console.WriteLine("    • Safe to have one producer, one consumer");

        return Task.CompletedTask;
    }

    private static void Section(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"  ── {title} ──");
        Console.WriteLine();
    }
}