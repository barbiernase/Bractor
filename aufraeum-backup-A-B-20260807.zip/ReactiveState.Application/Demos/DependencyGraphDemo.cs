using ReactiveState.Graph;

namespace ReactiveState.Application.Demos;

public static class DependencyGraphDemo
{
    public static Task RunAsync()
    {
        // === Simple Graph with Builder ===
        Section("Building a Simple Graph");
        
        var simpleGraph = new DependencyGraphBuilder()
            .AddTracked("Count")
            .AddComputed("Doubled", dependsOn: new[] { "Count" })
            .AddComputed("Quadrupled", dependsOn: new[] { "Doubled" })
            .AddComputed("Summary", dependsOn: new[] { "Count", "Doubled", "Quadrupled" })
            .Build();

        Console.WriteLine("  Nodes:");
        foreach (var graphNode in simpleGraph.Nodes.OrderBy(n => n.Level).ThenBy(n => n.Path))
        {
            Console.WriteLine($"    Level {graphNode.Level}: {graphNode.Path} ({graphNode.Kind})");
        }

        // === GetAffected ===
        Section("GetAffected() - What needs recomputation?");
        
        Console.WriteLine("  When 'Count' changes, what is affected?");
        var affected = simpleGraph.GetAffected("Count");
        Console.WriteLine($"    → [{string.Join(", ", affected)}]");
        Console.WriteLine();
        Console.WriteLine("  Note: Results are sorted by level (Doubled=1, Quadrupled=2, Summary=3)");

        // === GetAllDependencies ===
        Section("GetAllDependencies() - What does it depend on?");
        
        Console.WriteLine("  What does 'Summary' depend on?");
        var deps = simpleGraph.GetAllDependencies("Summary");
        Console.WriteLine($"    → [{string.Join(", ", deps)}]");

        // === Direct Relationships ===
        Section("Direct vs Transitive Relationships");
        
        Console.WriteLine("  GetDirectDependents(\"Count\"):");
        Console.WriteLine($"    → [{string.Join(", ", simpleGraph.GetDirectDependents("Count"))}]");
        Console.WriteLine();
        Console.WriteLine("  GetAffected(\"Count\") [transitive]:");
        Console.WriteLine($"    → [{string.Join(", ", simpleGraph.GetAffected("Count"))}]");

        // === Collection Graph ===
        Section("Graph with Collections");
        
        var todoGraph = new DependencyGraphBuilder()
            .AddTracked("Todos")
            .AddTracked("Todos[*].Title")
            .AddTracked("Todos[*].IsCompleted")
            .AddComputed("Todos[*].DisplayTitle", dependsOn: new[] { "Todos[*].Title", "Todos[*].IsCompleted" })
            .AddComputed("TodoCount", dependsOn: new[] { "Todos" })
            .AddComputed("OpenCount", dependsOn: new[] { "Todos", "Todos[*].IsCompleted" })
            .AddComputed("AllDone", dependsOn: new[] { "TodoCount", "OpenCount" })
            .Build();

        Console.WriteLine("  Nodes:");
        foreach (var todoNode in todoGraph.Nodes.OrderBy(n => n.Level).ThenBy(n => n.Path))
        {
            Console.WriteLine($"    Level {todoNode.Level}: {todoNode.Path}");
        }

        // === Item Change Propagation ===
        Section("Item Change Propagation");
        
        Console.WriteLine("  When 'Todos[id:abc].IsCompleted' changes:");
        var itemAffected = todoGraph.GetAffectedByItemChange("Todos", "abc", "IsCompleted");
        foreach (var path in itemAffected)
        {
            Console.WriteLine($"    → {path}");
        }

        // === Collection Change ===
        Section("Collection Change (Add/Remove)");
        
        Console.WriteLine("  When an item is added/removed from 'Todos':");
        var collectionAffected = todoGraph.GetAffectedByCollectionChange("Todos");
        foreach (var path in collectionAffected)
        {
            Console.WriteLine($"    → {path}");
        }

        // === Level Queries ===
        Section("Level Queries");
        
        Console.WriteLine($"  MaxLevel: {todoGraph.MaxLevel}");
        Console.WriteLine();
        
        for (int level = 0; level <= todoGraph.MaxLevel; level++)
        {
            var pathsAtLevel = todoGraph.GetPathsAtLevel(level);
            Console.WriteLine($"  Level {level}: [{string.Join(", ", pathsAtLevel)}]");
        }

        // === Validation ===
        Section("Graph Validation");
        
        var validGraph = new DependencyGraphBuilder()
            .AddTracked("A")
            .AddComputed("B", dependsOn: new[] { "A" })
            .Build();

        var errors = validGraph.Validate();
        Console.WriteLine($"  Valid graph has {errors.Count} errors");

        Console.WriteLine();
        Console.WriteLine("  Creating a graph with incorrect levels...");
        
        // Manually create a graph with wrong levels
        var badGraph = new DependencyGraph(
            nodes: new[]
            {
                GraphNode.Tracked("X"),
                new GraphNode { Path = "Y", Kind = NodeKind.Computed, Level = 1 },
                new GraphNode { Path = "Z", Kind = NodeKind.Computed, Level = 1 }, // Should be 2!
            },
            edges: new[]
            {
                GraphEdge.Create("X", "Y"),
                GraphEdge.Create("Y", "Z"),
            }
        );

        var badErrors = badGraph.Validate();
        Console.WriteLine($"  Invalid graph has {badErrors.Count} error(s):");
        foreach (var error in badErrors)
        {
            Console.WriteLine($"    • {error}");
        }

        // === HasNode / GetNode ===
        Section("Node Lookup");
        
        Console.WriteLine($"  todoGraph.HasNode(\"Todos\") = {todoGraph.HasNode("Todos")}");
        Console.WriteLine($"  todoGraph.HasNode(\"Other\") = {todoGraph.HasNode("Other")}");
        Console.WriteLine();
        
        var foundNode = todoGraph.GetNode("TodoCount");
        if (foundNode != null)
        {
            Console.WriteLine($"  GetNode(\"TodoCount\") = {foundNode}");
        }

        // === Template Paths ===
        Section("Template Paths");
        
        Console.WriteLine("  TemplatePaths in todoGraph:");
        foreach (var tp in todoGraph.TemplatePaths)
        {
            Console.WriteLine($"    • {tp}");
        }

        return Task.CompletedTask;
    }

    private static void Section(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"  ── {title} ──");
        Console.WriteLine();
    }
}