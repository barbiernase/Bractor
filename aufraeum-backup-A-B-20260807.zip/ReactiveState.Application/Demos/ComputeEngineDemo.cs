using ReactiveState.Runtime;

namespace ReactiveState.Application.Demos;

public static class ComputeEngineDemo
{
    public static async Task RunAsync()
    {
        // === Setup ===
        Section("Setting Up ComputeEngine");
        
        using var engine = new ComputeEngine();

        // Register computers
        int count = 10;
        
        engine.Register("Doubled", level: 1, () => count * 2);
        engine.Register("Tripled", level: 1, () => count * 3);
        engine.Register("Message", level: 2, () => $"Count is {count}");

        Console.WriteLine("  Registered: Doubled (level 1), Tripled (level 1), Message (level 2)");

        // === Initial State ===
        Section("Initial Cache State");
        
        Console.WriteLine($"  GetCached<int>(\"Doubled\") = {engine.GetCached<int>("Doubled")}");
        Console.WriteLine($"  GetCached<int>(\"Tripled\") = {engine.GetCached<int>("Tripled")}");
        Console.WriteLine($"  HasCached(\"Doubled\") = {engine.HasCached("Doubled")}");

        // === Synchronous Computation ===
        Section("Synchronous Computation");
        
        Console.WriteLine("  Computing 'Doubled' synchronously...");
        var result = engine.ComputeSync("Doubled");
        
        Console.WriteLine($"  Result: HasChanged={result.HasChanged}, OldValue={result.OldValue}, NewValue={result.NewValue}");
        Console.WriteLine($"  GetCached<int>(\"Doubled\") = {engine.GetCached<int>("Doubled")}");

        // === Scheduling ===
        Section("Scheduling Computations");
        
        // Listen for computed changes
        var changesReceived = new List<Change>();
        engine.OnComputed += changes =>
        {
            changesReceived.AddRange(changes);
            Console.WriteLine($"    📢 OnComputed: {changes.Count} change(s)");
            foreach (var c in changes)
            {
                Console.WriteLine($"       • {c}");
            }
        };

        Console.WriteLine("  Scheduling 'Tripled' and 'Message'...");
        engine.Schedule("Tripled");
        engine.Schedule("Message");

        // Wait for background computation
        await Task.Delay(100);

        Console.WriteLine();
        Console.WriteLine($"  After scheduling:");
        Console.WriteLine($"    GetCached<int>(\"Tripled\") = {engine.GetCached<int>("Tripled")}");
        Console.WriteLine($"    GetCached<string>(\"Message\") = {engine.GetCached<string>("Message")}");

        // === Recomputation ===
        Section("Recomputation After Value Change");
        
        Console.WriteLine("  Changing count from 10 to 20...");
        count = 20;
        
        Console.WriteLine("  Scheduling all for recomputation...");
        engine.Schedule(new[] { "Doubled", "Tripled", "Message" });
        
        await Task.Delay(100);
        
        Console.WriteLine();
        Console.WriteLine($"  New cached values:");
        Console.WriteLine($"    Doubled = {engine.GetCached<int>("Doubled")}");
        Console.WriteLine($"    Tripled = {engine.GetCached<int>("Tripled")}");
        Console.WriteLine($"    Message = {engine.GetCached<string>("Message")}");

        // === FlushSync ===
        Section("FlushSync (Synchronous Batch)");
        
        count = 100;
        engine.Schedule(new[] { "Doubled", "Tripled" });
        
        Console.WriteLine("  Calling FlushSync() instead of waiting...");
        var syncChanges = engine.FlushSync();
        
        Console.WriteLine($"  FlushSync returned {syncChanges.Count} changes:");
        foreach (var c in syncChanges)
        {
            Console.WriteLine($"    • {c}");
        }

        // === Error Handling ===
        Section("Error Handling");
        
        engine.Register("WillFail", level: 1, () => 
        {
            throw new InvalidOperationException("Simulated failure!");
        });
        
        engine.Schedule("WillFail");
        await Task.Delay(100);
        
        var failedValue = engine.GetCached<int>("WillFail");
        Console.WriteLine($"  GetCached<int>(\"WillFail\") = {failedValue}");
        Console.WriteLine($"  IsFailed = {failedValue.IsFailed}");

        // === Cache Invalidation ===
        Section("Cache Invalidation");
        
        Console.WriteLine($"  HasCached(\"Doubled\") = {engine.HasCached("Doubled")}");
        engine.InvalidateCache("Doubled");
        Console.WriteLine($"  After InvalidateCache:");
        Console.WriteLine($"  HasCached(\"Doubled\") = {engine.HasCached("Doubled")}");
        Console.WriteLine($"  GetCached<int>(\"Doubled\") = {engine.GetCached<int>("Doubled")}");

        // === Async Computation ===
        Section("Async Computation");
        
        engine.RegisterAsync("SlowComputed", level: 1, async () =>
        {
            Console.WriteLine("    ⏳ SlowComputed starting...");
            await Task.Delay(50);
            Console.WriteLine("    ✓ SlowComputed finished");
            return 42;
        });
        
        engine.Schedule("SlowComputed");
        await Task.Delay(100);
        
        Console.WriteLine($"  GetCached<int>(\"SlowComputed\") = {engine.GetCached<int>("SlowComputed")}");

        Console.WriteLine();
        Console.WriteLine("  Demo complete!");
    }

    private static void Section(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"  ── {title} ──");
        Console.WriteLine();
    }
}