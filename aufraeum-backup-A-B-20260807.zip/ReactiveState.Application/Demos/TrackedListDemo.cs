namespace ReactiveState.Application.Demos;

using ReactiveState;
using ReactiveState.Collections;
using ReactiveState.Graph;

public static class TrackedListDemo
{
    public static async Task RunAsync()
    {
        Console.WriteLine("═══════════════════════════════════════════════════════════");
        Console.WriteLine("  TrackedList Demo");
        Console.WriteLine("═══════════════════════════════════════════════════════════");

        // ───────────────────────────────────────────────────────────
        //  Setup
        // ───────────────────────────────────────────────────────────

        Section("Setup: Graph + Store + TrackedList");

        var graph = new DependencyGraphBuilder()
            .AddTracked("Todos")
            .AddTracked("Todos[*].Title")
            .AddTracked("Todos[*].IsCompleted")
            .AddTracked("Todos[*].Priority")
            .AddComputed("TodoCount", dependsOn: "Todos")
            .AddComputed("OpenCount", dependsOn: new[] {"Todos", "Todos[*].IsCompleted"})
            .Build();

        var state = new TodoAppState();
        
        var options = new StateStoreOptions
        {
            UseDebouncing = false,
            OnlyComputeSubscribed = false  // Compute everything for demo
        };
        
        using var store = new StateStore<TodoAppState>(state, graph, options);
        state.Connect(store);

        // Register computed properties
        store.RegisterComputed("TodoCount", () => state.Todos.Count);
        store.RegisterComputed("OpenCount", () => state.Todos.Items.Count(t => !t.IsCompleted));

        Console.WriteLine("  Graph, Store, and TrackedList created.");

        // ───────────────────────────────────────────────────────────
        //  Demo 1: Single Add
        // ───────────────────────────────────────────────────────────

        Section("Single Add");

        state.Todos.Add(new TodoItem("todo-1") { Title = "Einkaufen", Priority = 3 });

        PrintChanges(store);
        Console.WriteLine($"  Count: {state.Todos.Count}");

        // ───────────────────────────────────────────────────────────
        //  Demo 2: Bulk Add
        // ───────────────────────────────────────────────────────────

        Section("Bulk Add");

        state.Todos.AddRange(new[]
        {
            new TodoItem("todo-2") { Title = "Sport", Priority = 5 },
            new TodoItem("todo-3") { Title = "Lernen", Priority = 8 },
            new TodoItem("todo-4") { Title = "Kochen", Priority = 2 },
        });

        PrintChanges(store);
        Console.WriteLine($"  Count: {state.Todos.Count}");

        // ───────────────────────────────────────────────────────────
        //  Demo 3: Item Property Change
        // ───────────────────────────────────────────────────────────

        Section("Item Property Change");

        var todo = state.Todos.GetById("todo-1");
        Console.WriteLine($"  Before: '{todo!.Title}' IsCompleted={todo.IsCompleted}");

        todo.IsCompleted = true;

        PrintChanges(store);
        Console.WriteLine($"  After:  '{todo.Title}' IsCompleted={todo.IsCompleted}");

        // ───────────────────────────────────────────────────────────
        //  Demo 4: Multiple Property Changes
        // ───────────────────────────────────────────────────────────

        Section("Multiple Property Changes");

        var todo2 = state.Todos.GetById("todo-2")!;
        todo2.Title = "Joggen";
        todo2.Priority = 9;
        todo2.IsCompleted = true;

        PrintChanges(store);

        // ───────────────────────────────────────────────────────────
        //  Demo 5: ID-based Access
        // ───────────────────────────────────────────────────────────

        Section("ID-based Access");

        Console.WriteLine($"  GetById('todo-3'):    {state.Todos.GetById("todo-3")?.Title ?? "null"}");
        Console.WriteLine($"  GetById('invalid'):   {state.Todos.GetById("invalid")?.Title ?? "null"}");
        Console.WriteLine($"  ContainsId('todo-4'): {state.Todos.ContainsId("todo-4")}");
        Console.WriteLine($"  ContainsId('nope'):   {state.Todos.ContainsId("nope")}");

        if (state.Todos.TryGetById("todo-3", out var found))
        {
            Console.WriteLine($"  TryGetById found:     '{found!.Title}'");
        }

        // ───────────────────────────────────────────────────────────
        //  Demo 6: Single Remove
        // ───────────────────────────────────────────────────────────

        Section("Single Remove");

        Console.WriteLine($"  Before: Count={state.Todos.Count}");
        var removed = state.Todos.Remove("todo-4");
        Console.WriteLine($"  Remove('todo-4'): {removed}");

        PrintChanges(store);
        Console.WriteLine($"  After:  Count={state.Todos.Count}");

        // ───────────────────────────────────────────────────────────
        //  Demo 7: Bulk Remove
        // ───────────────────────────────────────────────────────────

        Section("Bulk Remove");

        // Add some completed items first
        state.Todos.AddRange(new[]
        {
            new TodoItem("todo-5") { Title = "Putzen", IsCompleted = true },
            new TodoItem("todo-6") { Title = "Waschen", IsCompleted = true },
        });
        store.ConsumeChanges(); // Clear for demo

        Console.WriteLine($"  Before: Count={state.Todos.Count}, Completed={state.Todos.Items.Count(t => t.IsCompleted)}");

        var removedCount = state.Todos.RemoveWhere(t => t.IsCompleted);
        Console.WriteLine($"  RemoveWhere(IsCompleted): {removedCount} items");

        PrintChanges(store);
        Console.WriteLine($"  After:  Count={state.Todos.Count}");

        // ───────────────────────────────────────────────────────────
        //  Demo 8: Replace All
        // ───────────────────────────────────────────────────────────

        Section("Replace All");

        Console.WriteLine($"  Before: [{string.Join(", ", state.Todos.Items.Select(t => t.Title))}]");

        state.Todos.ReplaceAll(new[]
        {
            new TodoItem("new-1") { Title = "Komplett" },
            new TodoItem("new-2") { Title = "Neue" },
            new TodoItem("new-3") { Title = "Liste" },
        });

        PrintChanges(store);
        Console.WriteLine($"  After:  [{string.Join(", ", state.Todos.Items.Select(t => t.Title))}]");

        // ───────────────────────────────────────────────────────────
        //  Demo 9: Clear
        // ───────────────────────────────────────────────────────────

        Section("Clear");

        Console.WriteLine($"  Before: Count={state.Todos.Count}");
        state.Todos.Clear();

        PrintChanges(store);
        Console.WriteLine($"  After:  Count={state.Todos.Count}");

        // ───────────────────────────────────────────────────────────
        //  Demo 10: Subscriptions
        // ───────────────────────────────────────────────────────────

        Section("Subscriptions");

        state.Todos.AddRange(new[]
        {
            new TodoItem("a") { Title = "Low", Priority = 2 },
            new TodoItem("b") { Title = "Medium", Priority = 5 },
        });
        store.ConsumeChanges();

        Console.WriteLine("  Subscribing to 'Todos[*].Title'...");
        var sub = store.Subscribe("Todos[*].Title", change =>
        {
            Console.WriteLine($"    📢 Title changed: {change.Path} = {change.NewValue}");
        });

        Console.WriteLine("  Changing todo title...");
        state.Todos.GetById("a")!.Title = "Updated Title";

// Force synchronous notification
        store.FlushSync();

        sub.Dispose();
        Console.WriteLine("  Subscription disposed");
        // ───────────────────────────────────────────────────────────
        //  Demo 11: Detach
        // ───────────────────────────────────────────────────────────

        Section("Detach (Changes Stop)");

        state.Todos.Detach();
        Console.WriteLine("  List detached.");

        state.Todos.GetById("a")!.Title = "Changed after detach";
        state.Todos.Add(new TodoItem("e") { Title = "Added after detach" });

        Console.WriteLine($"  Changes after mutations: {store.GetChanges().Count} (expected: 0)");

        // ───────────────────────────────────────────────────────────

        Console.WriteLine();
        Console.WriteLine("═══════════════════════════════════════════════════════════");
        Console.WriteLine("  Demo complete!");
        Console.WriteLine("═══════════════════════════════════════════════════════════");
    }

    private static void Section(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"  ── {title} ──");
        Console.WriteLine();
    }

    private static void PrintChanges(StateStore<TodoAppState> store)
    {
        var changes = store.ConsumeChanges();

        Console.WriteLine($"  Changes ({changes.Count}):");

        foreach (var change in changes)
        {
            var info = FormatChangeValue(change);
            Console.WriteLine($"    {change.Kind,-10} {change.Path,-35} {info}");
        }
    }

    private static string FormatChangeValue(Change change)
    {
        return change.Kind switch
        {
            ChangeKind.Add when change.NewValue is TodoItem item
                => $"'{item.Title}'",
            ChangeKind.Remove when change.OldValue is TodoItem item
                => $"'{item.Title}'",
            ChangeKind.Clear
                => $"{change.OldValue} items removed",
            ChangeKind.Set
                => $"{change.OldValue} → {change.NewValue}",
            _
                => $"{change.OldValue} → {change.NewValue}"
        };
    }
}

/// <summary>
/// Demo state with TrackedList.
/// </summary>
public class TodoAppState
{
    private IStateStore? _store;
    
    public TrackedList<TodoItem> Todos { get; } = new();

    public void Connect(IStateStore store)
    {
        _store = store;
        Todos.Attach(store, "Todos");
    }
}

/// <summary>
/// Demo TodoItem (would be generated in real usage).
/// </summary>
/// <summary>
/// Demo TodoItem (would be generated in real usage).
/// </summary>
/// <summary>
/// Demo TodoItem (would be generated in real usage).
/// </summary>
public class TodoItem : IReactiveItem
{
    private IStateStore? _store;
    private string? _pathPrefix;

    private readonly string _id;
    private string _title = "";
    private bool _isCompleted;
    private int _priority;

    public TodoItem(string id)
    {
        _id = id;
    }

    public string Id => _id;

    public void __Connect(IStateStore store, string pathPrefix)
    {
        _store = store;
        _pathPrefix = pathPrefix;
    }

    public void __Disconnect()
    {
        _store = null;
        _pathPrefix = null;
    }

    private string? GetCollectionPath()
    {
        if (_pathPrefix == null) return null;
        var bracketIndex = _pathPrefix.IndexOf('[');
        return bracketIndex > 0 ? _pathPrefix[..bracketIndex] : null;
    }

    public string Title
    {
        get => _title;
        set
        {
            if (_title != value)
            {
                var old = _title;
                _title = value;
                
                var collectionPath = GetCollectionPath();
                if (_store != null && collectionPath != null)
                {
                    _store.NotifyItemChanged(collectionPath, _id, "Title", old, value);
                }
            }
        }
    }

    public bool IsCompleted
    {
        get => _isCompleted;
        set
        {
            if (_isCompleted != value)
            {
                var old = _isCompleted;
                _isCompleted = value;
                
                var collectionPath = GetCollectionPath();
                if (_store != null && collectionPath != null)
                {
                    _store.NotifyItemChanged(collectionPath, _id, "IsCompleted", old, value);
                }
            }
        }
    }

    public int Priority
    {
        get => _priority;
        set
        {
            if (_priority != value)
            {
                var old = _priority;
                _priority = value;
                
                var collectionPath = GetCollectionPath();
                if (_store != null && collectionPath != null)
                {
                    _store.NotifyItemChanged(collectionPath, _id, "Priority", old, value);
                }
            }
        }
    }
}