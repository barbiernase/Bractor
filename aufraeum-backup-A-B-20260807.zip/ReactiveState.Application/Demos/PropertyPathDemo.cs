using ReactiveState.Graph;

namespace ReactiveState.Application.Demos;

public static class PropertyPathDemo
{
    public static Task RunAsync()
    {
        // === Template vs Instance ===
        Section("Template vs Instance Paths");
        
        var template = "Todos[*].Title";
        var instance = "Todos[id:abc123].Title";

        Console.WriteLine($"  Template: {template}");
        Console.WriteLine($"  Instance: {instance}");
        Console.WriteLine();
        Console.WriteLine($"  IsTemplate(\"{template}\") = {PropertyPath.IsTemplate(template)}");
        Console.WriteLine($"  IsTemplate(\"{instance}\") = {PropertyPath.IsTemplate(instance)}");
        Console.WriteLine($"  IsInstance(\"{template}\") = {PropertyPath.IsInstance(template)}");
        Console.WriteLine($"  IsInstance(\"{instance}\") = {PropertyPath.IsInstance(instance)}");

        // === Conversion ===
        Section("Template ↔ Instance Conversion");
        
        Console.WriteLine($"  ToInstance(\"{template}\", \"xyz\")");
        Console.WriteLine($"    → {PropertyPath.ToInstance(template, "xyz")}");
        Console.WriteLine();
        Console.WriteLine($"  ToTemplate(\"{instance}\")");
        Console.WriteLine($"    → {PropertyPath.ToTemplate(instance)}");

        // === Extraction ===
        Section("Extracting Parts");
        
        var complexPath = "Orders[id:order-42].Items[id:item-7].Price";
        Console.WriteLine($"  Path: {complexPath}");
        Console.WriteLine();
        Console.WriteLine($"  ExtractId()             = {PropertyPath.ExtractId(complexPath) ?? "(null)"}");
        Console.WriteLine($"  ExtractCollectionPath() = {PropertyPath.ExtractCollectionPath(complexPath) ?? "(null)"}");
        Console.WriteLine($"  ExtractItemProperty()   = {PropertyPath.ExtractItemProperty(complexPath) ?? "(null)"}");
        Console.WriteLine($"  GetPropertyName()       = {PropertyPath.GetPropertyName(complexPath)}");
        Console.WriteLine($"  GetParent()             = {PropertyPath.GetParent(complexPath) ?? "(null)"}");

        // === Simpler Path ===
        Section("Simple Path Extraction");
        
        var simplePath = "Address.City";
        Console.WriteLine($"  Path: {simplePath}");
        Console.WriteLine();
        Console.WriteLine($"  GetPropertyName() = {PropertyPath.GetPropertyName(simplePath)}");
        Console.WriteLine($"  GetParent()       = {PropertyPath.GetParent(simplePath) ?? "(null)"}");

        // === Combine ===
        Section("Combining Paths");
        
        Console.WriteLine($"  Combine(\"Address\", \"City\")           = {PropertyPath.Combine("Address", "City")}");
        Console.WriteLine($"  Combine(\"Todos[id:1]\", \"Title\")      = {PropertyPath.Combine("Todos[id:1]", "Title")}");
        Console.WriteLine($"  Combine(\"\", \"RootProp\")              = {PropertyPath.Combine("", "RootProp")}");

        // === Matching ===
        Section("Pattern Matching");
        
        var testCases = new[]
        {
            ("Todos[id:abc].Title", "Todos[*].Title"),
            ("Todos[id:abc].Title", "Todos[*].Name"),
            ("Todos[id:abc].Title", "Todos[id:abc].Title"),
            ("UserName", "UserName"),
            ("UserName", "User"),
        };

        Console.WriteLine("  Instance Path              │ Template Path         │ Matches?");
        Console.WriteLine("  ───────────────────────────┼───────────────────────┼─────────");
        
        foreach (var (inst, tmpl) in testCases)
        {
            var matches = PropertyPath.Matches(inst, tmpl);
            Console.WriteLine($"  {inst,-26} │ {tmpl,-21} │ {matches}");
        }

        // === Parent/Child Relationships ===
        Section("Parent/Child Relationships");
        
        var paths = new[]
        {
            ("Address.City", "Address"),
            ("Address", "Address"),
            ("Address.City.Street", "Address"),
            ("Todos[id:1].Title", "Todos"),
            ("UserName", "User"),
        };

        Console.WriteLine("  Path                    │ Parent     │ IsChildOf │ IsSameOrChildOf");
        Console.WriteLine("  ────────────────────────┼────────────┼───────────┼────────────────");
        
        foreach (var (path, parent) in paths)
        {
            var isChild = PropertyPath.IsChildOf(path, parent);
            var isSameOrChild = PropertyPath.IsSameOrChildOf(path, parent);
            Console.WriteLine($"  {path,-23} │ {parent,-10} │ {isChild,-9} │ {isSameOrChild}");
        }

        return Task.CompletedTask;
    }

    private static void Section(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"  ── {title} ──");
        Console.WriteLine();
    }
}