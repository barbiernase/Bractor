namespace Client.Avalonia;

public class Program
{
    
}