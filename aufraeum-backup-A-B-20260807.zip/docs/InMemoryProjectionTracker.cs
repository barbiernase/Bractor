using System.Collections.Concurrent;
using Abstractions;

namespace Infrastructure.Testing;

/// <summary>
/// In-Memory-Fortschrittsmarke für den Single-Node-Prüfstand (Phase 0.5 / Phase 2).
///
/// Ermöglicht die Crash-Proben OHNE Cluster: Marken leben im Prozess, lassen sich
/// gezielt zurücksetzen (Replay) und über einen Klon "durabel überstehen" simulieren.
/// Für Produktion nicht gedacht — dort läuft MartenProjectionTracker.
///
/// Der Prüfstand injiziert Fehler NICHT hier, sondern im Effekt-Store (z. B.
/// "wirf nach dem Effekt-Write, vor MarkProcessedAsync"). Dieser Tracker bleibt
/// bewusst simpel und ehrlich: eine ConcurrentDictionary, kein verstecktes Verhalten.
/// </summary>
public class InMemoryProjectionTracker : IProjectionTracker
{
    // Key: (projectionId, streamId) → höchste angewandte Version
    private readonly ConcurrentDictionary<(string, Guid), int> _marks = new();

    public Task<int> LastProcessedVersionAsync(
        string projectionId, Guid streamId, CancellationToken ct)
        => Task.FromResult(_marks.TryGetValue((projectionId, streamId), out var v) ? v : -1);

    public Task MarkProcessedAsync(
        string projectionId, Guid streamId, int version, CancellationToken ct)
    {
        _marks[(projectionId, streamId)] = version;
        return Task.CompletedTask;
    }

    public Task ResetAsync(string projectionId, Guid streamId, CancellationToken ct)
    {
        _marks.TryRemove((projectionId, streamId), out _);
        return Task.CompletedTask;
    }

    public Task ResetAllAsync(string projectionId, CancellationToken ct)
    {
        foreach (var key in _marks.Keys)
            if (key.Item1 == projectionId)
                _marks.TryRemove(key, out _);
        return Task.CompletedTask;
    }

    // ─── Prüfstand-Hilfen (nicht Teil von IProjectionTracker) ───

    /// <summary>Simuliert einen Node-Neustart: Marken bleiben (durabel), alles
    /// Uncommittete des Effekt-Stores wird dort separat verworfen.</summary>
    public InMemoryProjectionTracker Snapshot()
    {
        var copy = new InMemoryProjectionTracker();
        foreach (var kv in _marks) copy._marks[kv.Key] = kv.Value;
        return copy;
    }
}
