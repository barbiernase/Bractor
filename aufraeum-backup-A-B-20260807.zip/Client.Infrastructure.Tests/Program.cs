namespace Client.Infrastructure.Tests;

public class Program
{
    
}