﻿namespace Infrastructure.PubSub.Tests;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}
