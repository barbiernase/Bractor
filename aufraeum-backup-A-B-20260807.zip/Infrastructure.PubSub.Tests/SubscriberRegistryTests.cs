namespace Infrastructure.PubSub.Tests;

using FluentAssertions;
using Proto;

public class SubscriberRegistryTests
{
    private readonly SubscriberRegistry _sut = new();
    
    private static PID CreatePid(string id) 
        => PID.FromAddress("test", id);

    [Fact]
    public void Add_IncreasesCount()
    {
        _sut.Add("sub-1", CreatePid("a"));
        
        _sut.Count.Should().Be(1);
    }

    [Fact]
    public void Add_SameId_Overwrites()
    {
        var pid1 = CreatePid("a");
        var pid2 = CreatePid("b");
        
        _sut.Add("sub-1", pid1);
        _sut.Add("sub-1", pid2);
        
        _sut.Count.Should().Be(1);
        _sut.Subscribers.Should().Contain(pid2);
        _sut.Subscribers.Should().NotContain(pid1);
    }

    [Fact]
    public void Add_MultipleSubscribers_AllStored()
    {
        _sut.Add("sub-1", CreatePid("a"));
        _sut.Add("sub-2", CreatePid("b"));
        _sut.Add("sub-3", CreatePid("c"));
        
        _sut.Count.Should().Be(3);
    }

    [Fact]
    public void Remove_ExistingSubscriber_ReturnsTrue()
    {
        _sut.Add("sub-1", CreatePid("a"));
        
        var result = _sut.Remove("sub-1");
        
        result.Should().BeTrue();
        _sut.Count.Should().Be(0);
    }

    [Fact]
    public void Remove_NonExisting_ReturnsFalse()
    {
        var result = _sut.Remove("non-existing");
        
        result.Should().BeFalse();
    }

    [Fact]
    public void Contains_ExistingSubscriber_ReturnsTrue()
    {
        _sut.Add("sub-1", CreatePid("a"));
        
        _sut.Contains("sub-1").Should().BeTrue();
    }

    [Fact]
    public void Contains_NonExisting_ReturnsFalse()
    {
        _sut.Contains("non-existing").Should().BeFalse();
    }

    [Fact]
    public void Clear_RemovesAll()
    {
        _sut.Add("sub-1", CreatePid("a"));
        _sut.Add("sub-2", CreatePid("b"));
        
        _sut.Clear();
        
        _sut.Count.Should().Be(0);
    }

    [Fact]
    public void Subscribers_ReturnsAllPids()
    {
        var pid1 = CreatePid("a");
        var pid2 = CreatePid("b");
        
        _sut.Add("sub-1", pid1);
        _sut.Add("sub-2", pid2);
        
        _sut.Subscribers.Should().Contain(pid1);
        _sut.Subscribers.Should().Contain(pid2);
    }

    [Fact]
    public void Add_NullSubscriberId_Throws()
    {
        var act = () => _sut.Add(null!, CreatePid("a"));
        
        act.Should().Throw<ArgumentNullException>();
    }

    [Fact]
    public void Add_NullPid_Throws()
    {
        var act = () => _sut.Add("sub-1", null!);
        
        act.Should().Throw<ArgumentNullException>();
    }
}