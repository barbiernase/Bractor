namespace Infrastructure.PubSub.Tests;

using Abstractions;
using FluentAssertions;

public class BrokerIdentityTests
{
    // Test-Typen
    private record TestEvent : IEvent;
    private record TestCommand : ICommand;

    [Fact]
    public void Manager_ReturnsCorrectIdentity()
    {
        var identity = BrokerIdentity.Manager<TestEvent>();
        
        identity.Identity.Should().Be(nameof(TestEvent));
        identity.Kind.Should().Be(PubSubConfiguration.ManagerKind);
    }

    [Fact]
    public void Shard_ReturnsCorrectIdentity()
    {
        var identity = BrokerIdentity.Shard<TestEvent>(1);
        
        identity.Identity.Should().Be("TestEvent_1");
        identity.Kind.Should().Be(PubSubConfiguration.ShardKind);
    }

    [Theory]
    [InlineData(-1)]
    [InlineData(3)]
    public void Shard_InvalidIndex_Throws(int index)
    {
        var act = () => BrokerIdentity.Shard<TestEvent>(index);
        act.Should().Throw<ArgumentOutOfRangeException>();
    }

    [Fact]
    public void ShardFor_SameSubscriber_ReturnsSameShard()
    {
        var shard1 = BrokerIdentity.ShardFor<TestEvent>("sub-1");
        var shard2 = BrokerIdentity.ShardFor<TestEvent>("sub-1");
        
        shard1.Identity.Should().Be(shard2.Identity);
    }

    [Fact]
    public void ShardFor_WorksWithCommands()
    {
        var identity = BrokerIdentity.ShardFor<TestCommand>("sub-1");
        
        identity.Identity.Should().StartWith(nameof(TestCommand));
    }

    [Fact]
    public void GetShardIndex_DistributesEvenly()
    {
        var distribution = Enumerable.Range(0, 1000)
            .Select(i => BrokerIdentity.GetShardIndex($"subscriber-{i}"))
            .GroupBy(i => i)
            .Select(g => g.Count())
            .ToList();
        
        // Alle Shards genutzt
        distribution.Should().HaveCount(PubSubConfiguration.ShardCount);
        
        // Halbwegs gleichmäßig (min 20% vom Durchschnitt)
        var avg = 1000 / PubSubConfiguration.ShardCount;
        distribution.Should().AllSatisfy(c => c.Should().BeGreaterThan(avg / 5));
    }

    [Fact]
    public void AllShards_ReturnsAllShards()
    {
        var shards = BrokerIdentity.AllShards<TestEvent>();
        
        shards.Should().HaveCount(PubSubConfiguration.ShardCount);
        shards.Select(s => s.Identity).Should().OnlyHaveUniqueItems();
    }

    [Fact]
    public void ParseShardIdentity_ExtractsCorrectly()
    {
        var (typeName, index) = BrokerIdentity.ParseShardIdentity("TestEvent_2");
        
        typeName.Should().Be("TestEvent");
        index.Should().Be(2);
    }

    [Fact]
    public void ParseShardIdentity_HandlesUnderscoresInName()
    {
        var (typeName, index) = BrokerIdentity.ParseShardIdentity("Some_Event_1");
        
        typeName.Should().Be("Some_Event");
        index.Should().Be(1);
    }
}
