namespace Infrastructure.PubSub.Tests;

using Abstractions;
using FluentAssertions;
using Proto;

public class BrokerSubscriptionTests
{
    private record TestEvent : IEvent;

    [Fact]
    public void Constructor_NullCluster_Throws()
    {
        var pid = PID.FromAddress("test", "actor");
        
        var act = () => new BrokerSubscription(null!, "sub-1", pid);
        
        act.Should().Throw<ArgumentNullException>();
    }

    [Fact]
    public void Constructor_NullSubscriberId_Throws()
    {
        var pid = PID.FromAddress("test", "actor");
        
        // Cluster können wir nicht einfach mocken, daher nur null-check testen
        var act = () => new BrokerSubscription(null!, null!, pid);
        
        act.Should().Throw<ArgumentNullException>();
    }

    [Fact]
    public void Constructor_NullPid_Throws()
    {
        var act = () => new BrokerSubscription(null!, "sub-1", null!);
        
        act.Should().Throw<ArgumentNullException>();
    }
}